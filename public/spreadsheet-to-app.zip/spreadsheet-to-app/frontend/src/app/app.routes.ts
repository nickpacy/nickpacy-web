import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'apps',
    pathMatch: 'full'
  },
  {
    path: 'apps',
    loadComponent: () =>
      import('./components/app-list/app-list.component').then(m => m.AppListComponent)
  },
  {
    path: 'app/:slug',
    loadComponent: () =>
      import('./components/app-grid/app-grid.component').then(m => m.AppGridComponent)
  },
  {
    path: 'upload',
    loadComponent: () =>
      import('./components/upload/upload.component').then(m => m.UploadComponent)
  },
  {
    path: 'upload/review/:tempFileId',
    loadComponent: () =>
      import('./components/schema-review/schema-review.component').then(m => m.SchemaReviewComponent)
  },
  {
    path: 'admin',
    loadComponent: () =>
      import('./components/admin/admin-panel.component').then(m => m.AdminPanelComponent)
  },
  {
    path: '**',
    redirectTo: 'apps'
  }
];
