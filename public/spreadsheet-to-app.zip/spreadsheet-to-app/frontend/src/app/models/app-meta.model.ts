export interface AppListItem {
  id: number;
  slug: string;
  displayName: string;
  permission: string;
  rowCount: number;
  createdAt: string;
  createdBy: string;
}

export interface AppColumn {
  id: number;
  appId: number;
  columnName: string;
  displayName: string;
  dataType: 'NVARCHAR' | 'INT' | 'DECIMAL' | 'DATE' | 'DATETIME' | 'BIT';
  maxLength: number | null;
  isRequired: boolean;
  isSearchable: boolean;
  isActive: boolean;
  columnOrder: number;
}

export interface AppMetadata {
  appId: number;
  slug: string;
  displayName: string;
  permission: string;
  columns: AppColumn[];
  rowCount: number;
  importStrategy: string;
  upsertKeyCol: string | null;
}

export interface InferredColumn {
  rawHeader: string;
  columnName: string;
  displayName: string;
  dataType: string;
  maxLength: number | null;
  confidence: number;
  warnings: string[];
  wasRenamed: boolean;
  isRequired: boolean;
  isSearchable: boolean;
  columnOrder: number;
  exclude: boolean;
}

export interface InferredSchema {
  tempFileId: string;
  originalFileName: string;
  sheetNames: string[];
  selectedSheet: string;
  totalRows: number;
  columns: InferredColumn[];
}

export interface ConfirmImportRequest {
  tempFileId: string;
  selectedSheet: string;
  appSlug: string;
  displayName: string;
  importStrategy: string;
  upsertKeyCol?: string;
  columns: InferredColumn[];
}

export interface PagedResult {
  totalCount: number;
  page: number;
  pageSize: number;
  rows: Record<string, unknown>[];
}

// Maps SQL Server types to DevExtreme grid/form types
export const TYPE_MAP: Record<string, { gridType: string; editor: string }> = {
  'NVARCHAR':  { gridType: 'string',   editor: 'dxTextBox'   },
  'INT':       { gridType: 'number',   editor: 'dxNumberBox' },
  'DECIMAL':   { gridType: 'number',   editor: 'dxNumberBox' },
  'DATE':      { gridType: 'date',     editor: 'dxDateBox'   },
  'DATETIME':  { gridType: 'datetime', editor: 'dxDateBox'   },
  'BIT':       { gridType: 'boolean',  editor: 'dxCheckBox'  },
};
