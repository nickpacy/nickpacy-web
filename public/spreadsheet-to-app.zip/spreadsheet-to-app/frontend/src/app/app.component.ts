import { Component, OnInit, signal, inject } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from './services/api.service';
import { SignalRService } from './services/signalr.service';
import { AppListItem } from './models/app-meta.model';
import { DxListModule, DxButtonModule, DxToastModule, DxProgressBarModule } from 'devextreme-angular';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet, RouterLink, RouterLinkActive, CommonModule,
    DxListModule, DxButtonModule, DxToastModule, DxProgressBarModule
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  private api = inject(ApiService);
  private signalR = inject(SignalRService);

  apps = signal<AppListItem[]>([]);
  importProgress = signal<{ stage: string; current: number; total: number; percent: number } | null>(null);
  toastMessage = signal('');
  toastVisible = signal(false);

  ngOnInit() {
    this.loadApps();
    this.connectSignalR();
  }

  loadApps() {
    this.api.getApps().subscribe({
      next: apps => this.apps.set(apps),
      error: () => { /* user may not have any apps */ }
    });
  }

  private connectSignalR() {
    this.signalR.start();

    this.signalR.on('ImportProgress', (data) => {
      this.importProgress.set(data);
    });

    this.signalR.on('ImportComplete', (data: { slug: string; displayName: string; rowCount: number }) => {
      this.importProgress.set(null);
      this.showToast(`Import complete: "${data.displayName}" — ${data.rowCount} rows imported.`);
      this.loadApps();
    });

    this.signalR.on('ImportFailed', (data: { error: string }) => {
      this.importProgress.set(null);
      this.showToast(`Import failed: ${data.error}`, true);
    });
  }

  showToast(message: string, isError = false) {
    this.toastMessage.set(message);
    this.toastVisible.set(true);
  }
}
