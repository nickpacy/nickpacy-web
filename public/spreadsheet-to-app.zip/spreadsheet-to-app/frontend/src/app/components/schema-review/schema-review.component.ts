import { Component, OnInit, signal, inject } from '@angular/core';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { SignalRService } from '../../services/signalr.service';
import { InferredSchema, InferredColumn, ConfirmImportRequest } from '../../models/app-meta.model';
import {
  DxDataGridModule, DxButtonModule, DxSelectBoxModule,
  DxTextBoxModule, DxCheckBoxModule, DxTagBoxModule, DxToastModule
} from 'devextreme-angular';

@Component({
  selector: 'app-schema-review',
  standalone: true,
  imports: [
    RouterLink, CommonModule, FormsModule,
    DxDataGridModule, DxButtonModule, DxSelectBoxModule,
    DxTextBoxModule, DxCheckBoxModule, DxTagBoxModule, DxToastModule
  ],
  templateUrl: './schema-review.component.html',
  styleUrl: './schema-review.component.scss'
})
export class SchemaReviewComponent implements OnInit {
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private api = inject(ApiService);
  private signalR = inject(SignalRService);

  schema = signal<InferredSchema | null>(null);
  appSlug = signal('');
  displayName = signal('');
  importStrategy = signal('replace');
  upsertKeyCol = signal('');
  importing = signal(false);
  error = signal('');
  toastMessage = signal('');
  toastVisible = signal(false);

  readonly dataTypes = ['NVARCHAR', 'INT', 'DECIMAL', 'DATE', 'DATETIME', 'BIT'];
  readonly importStrategies = [
    { value: 'replace', text: 'Replace — truncate and reimport all rows' },
    { value: 'append', text: 'Append — add rows alongside existing data' },
    { value: 'upsert', text: 'Upsert — update matching rows, insert new ones' }
  ];

  ngOnInit() {
    // Schema passed via router state from UploadComponent
    const nav = this.router.getCurrentNavigation();
    const schema = nav?.extras?.state?.['schema'] as InferredSchema;
    if (schema) {
      this.schema.set(schema);
    } else {
      this.error.set('No schema data found. Please upload your file again.');
    }
  }

  get columns() { return this.schema()?.columns ?? []; }

  toggleExclude(col: InferredColumn) {
    col.exclude = !col.exclude;
  }

  get slugFromDisplayName() {
    return this.displayName()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
  }

  get upsertKeyOptions() {
    return this.columns.filter(c => !c.exclude).map(c => c.columnName);
  }

  confirmImport() {
    if (!this.displayName().trim()) {
      this.error.set('Please enter a name for this application.');
      return;
    }

    const schema = this.schema();
    if (!schema) return;

    const slug = this.appSlug() || this.slugFromDisplayName;
    this.importing.set(true);
    this.error.set('');

    const request: ConfirmImportRequest = {
      tempFileId: schema.tempFileId,
      selectedSheet: schema.selectedSheet,
      appSlug: slug,
      displayName: this.displayName(),
      importStrategy: this.importStrategy(),
      upsertKeyCol: this.importStrategy() === 'upsert' ? this.upsertKeyCol() : undefined,
      columns: this.columns.filter(c => !c.exclude)
    };

    this.api.confirmImport(request).subscribe({
      next: (result) => {
        this.importing.set(false);
        this.router.navigate(['/app', result.slug]);
      },
      error: (err) => {
        this.importing.set(false);
        this.error.set(err?.error?.error ?? 'Import failed. Please try again.');
      }
    });
  }

  confidenceClass(confidence: number): string {
    if (confidence >= 80) return 'confidence-high';
    if (confidence >= 60) return 'confidence-medium';
    return 'confidence-low';
  }
}
