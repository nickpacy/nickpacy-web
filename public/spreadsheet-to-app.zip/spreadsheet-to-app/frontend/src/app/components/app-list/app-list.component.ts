import { Component, OnInit, signal, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { AppListItem } from '../../models/app-meta.model';
import { DxDataGridModule, DxButtonModule } from 'devextreme-angular';

@Component({
  selector: 'app-app-list',
  standalone: true,
  imports: [RouterLink, CommonModule, DxDataGridModule, DxButtonModule],
  templateUrl: './app-list.component.html',
  styleUrl: './app-list.component.scss'
})
export class AppListComponent implements OnInit {
  private api = inject(ApiService);
  apps = signal<AppListItem[]>([]);
  loading = signal(true);

  ngOnInit() {
    this.api.getApps().subscribe({
      next: apps => { this.apps.set(apps); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
}
