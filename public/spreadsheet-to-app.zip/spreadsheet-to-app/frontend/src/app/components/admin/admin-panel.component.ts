import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import {
  DxDataGridModule, DxTabPanelModule, DxButtonModule,
  DxDateBoxModule, DxSelectBoxModule, DxTextBoxModule, DxToastModule
} from 'devextreme-angular';

@Component({
  selector: 'app-admin-panel',
  standalone: true,
  imports: [
    CommonModule, DxDataGridModule, DxTabPanelModule, DxButtonModule,
    DxDateBoxModule, DxSelectBoxModule, DxTextBoxModule, DxToastModule
  ],
  templateUrl: './admin-panel.component.html',
  styleUrl: './admin-panel.component.scss'
})
export class AdminPanelComponent implements OnInit {
  private api = inject(ApiService);

  activeTab = signal(0);
  users = signal<unknown[]>([]);
  apps = signal<unknown[]>([]);
  auditRows = signal<unknown[]>([]);
  auditTotal = signal(0);
  loading = signal(false);

  // Audit filters
  auditFilters = signal({
    changedBy: '',
    from: null as Date | null,
    to: null as Date | null,
    action: '' as string,
    page: 1,
    pageSize: 50
  });

  readonly actionTypes = ['', 'INSERT', 'UPDATE', 'DELETE', 'SCHEMA'];

  toastMessage = signal('');
  toastVisible = signal(false);

  ngOnInit() {
    this.loadUsers();
    this.loadApps();
    this.loadAudit();
  }

  loadUsers() {
    this.api.adminGetUsers().subscribe({ next: u => this.users.set(u) });
  }

  loadApps() {
    this.api.adminGetApps().subscribe({ next: a => this.apps.set(a) });
  }

  loadAudit() {
    const f = this.auditFilters();
    this.api.adminGetAudit({
      changedBy: f.changedBy || undefined,
      from: f.from?.toISOString() ?? undefined,
      to: f.to?.toISOString() ?? undefined,
      action: f.action || undefined,
      page: f.page,
      pageSize: f.pageSize
    }).subscribe({
      next: (result: unknown) => {
        const r = result as { rows: unknown[]; totalCount: number };
        this.auditRows.set(r.rows);
        this.auditTotal.set(r.totalCount);
      }
    });
  }

  toggleAdmin(user: Record<string, unknown>) {
    const newIsAdmin = !user['isAdmin'];
    this.api.adminUpdateUser(user['id'] as number, newIsAdmin, user['isActive'] as boolean)
      .subscribe({
        next: () => {
          this.loadUsers();
          this.showToast(`Admin flag ${newIsAdmin ? 'granted' : 'revoked'} for ${user['username']}.`);
        }
      });
  }

  showToast(msg: string) {
    this.toastMessage.set(msg);
    this.toastVisible.set(true);
  }
}
