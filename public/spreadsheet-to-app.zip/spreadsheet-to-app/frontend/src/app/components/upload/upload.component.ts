import { Component, signal, inject } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { InferredSchema } from '../../models/app-meta.model';
import { DxFileUploaderModule, DxButtonModule, DxLoadIndicatorModule, DxSelectBoxModule } from 'devextreme-angular';

@Component({
  selector: 'app-upload',
  standalone: true,
  imports: [CommonModule, DxFileUploaderModule, DxButtonModule, DxLoadIndicatorModule, DxSelectBoxModule],
  templateUrl: './upload.component.html',
  styleUrl: './upload.component.scss'
})
export class UploadComponent {
  private api = inject(ApiService);
  private router = inject(Router);

  selectedFile = signal<File | null>(null);
  uploading = signal(false);
  error = signal('');
  schema = signal<InferredSchema | null>(null);
  selectedSheet = signal('');

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files?.[0]) {
      this.selectedFile.set(input.files[0]);
      this.error.set('');
      this.schema.set(null);
    }
  }

  onFileDrop(files: File[]) {
    if (files[0]) {
      this.selectedFile.set(files[0]);
      this.error.set('');
      this.schema.set(null);
    }
  }

  upload() {
    const file = this.selectedFile();
    if (!file) return;

    this.uploading.set(true);
    this.error.set('');

    this.api.uploadFile(file, this.selectedSheet() || undefined).subscribe({
      next: (schema) => {
        this.uploading.set(false);
        this.schema.set(schema);
        // Navigate to schema review, passing the inferred schema via router state
        this.router.navigate(['/upload/review', schema.tempFileId], {
          state: { schema }
        });
      },
      error: (err) => {
        this.uploading.set(false);
        this.error.set(err?.error?.error ?? 'Upload failed. Please try again.');
      }
    });
  }

  onSheetSelected(sheetName: string) {
    const file = this.selectedFile();
    if (!file || !sheetName) return;
    this.uploading.set(true);
    this.api.uploadFile(file, sheetName).subscribe({
      next: (schema) => {
        this.uploading.set(false);
        this.schema.set(schema);
      },
      error: () => this.uploading.set(false)
    });
  }
}
