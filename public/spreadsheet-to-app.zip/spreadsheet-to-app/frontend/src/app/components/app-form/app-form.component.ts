import { Component, Input, Output, EventEmitter, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { AppColumn, TYPE_MAP } from '../../models/app-meta.model';
import { DxFormModule, DxButtonModule, DxTabPanelModule } from 'devextreme-angular';

@Component({
  selector: 'app-app-form',
  standalone: true,
  imports: [CommonModule, DxFormModule, DxButtonModule, DxTabPanelModule],
  templateUrl: './app-form.component.html',
  styleUrl: './app-form.component.scss'
})
export class AppFormComponent implements OnInit {
  @Input() slug = '';
  @Input() columns: AppColumn[] = [];
  @Input() rowId: number | null = null;
  @Input() rowData: Record<string, unknown> = {};
  @Output() saved = new EventEmitter<void>();
  @Output() cancelled = new EventEmitter<void>();

  private api = inject(ApiService);

  formData = signal<Record<string, unknown>>({});
  saving = signal(false);
  error = signal('');
  activeTab = signal(0);

  // DxForm items derived from column metadata (spec §6.1)
  formItems = signal<unknown[]>([]);

  ngOnInit() {
    this.formData.set({ ...this.rowData });
    this.formItems.set(this.buildFormItems());
  }

  private buildFormItems() {
    return this.columns.map(col => ({
      dataField: col.columnName,
      label: { text: col.displayName },
      editorType: TYPE_MAP[col.dataType]?.editor ?? 'dxTextBox',
      isRequired: col.isRequired,
      editorOptions: this.buildEditorOptions(col)
    }));
  }

  private buildEditorOptions(col: AppColumn): Record<string, unknown> {
    if (col.dataType === 'DATE') return { displayFormat: 'yyyy-MM-dd', type: 'date' };
    if (col.dataType === 'DATETIME') return { displayFormat: 'yyyy-MM-dd HH:mm', type: 'datetime' };
    if (col.dataType === 'INT') return { format: '#,##0' };
    if (col.dataType === 'DECIMAL') return { format: '#,##0.####' };
    return {};
  }

  save() {
    this.saving.set(true);
    this.error.set('');

    const data = this.formData();
    const request$ = this.rowId
      ? this.api.updateRow(this.slug, this.rowId, data)
      : this.api.insertRow(this.slug, data);

    request$.subscribe({
      next: () => { this.saving.set(false); this.saved.emit(); },
      error: (err) => {
        this.saving.set(false);
        this.error.set(err?.error?.error ?? 'Save failed. Please try again.');
      }
    });
  }
}
