import { Component, OnInit, OnDestroy, signal, computed, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { AppMetadata, AppColumn, PagedResult, TYPE_MAP } from '../../models/app-meta.model';
import {
  DxDataGridModule, DxButtonModule, DxPopupModule,
  DxLoadIndicatorModule, DxToastModule
} from 'devextreme-angular';
import { AppFormComponent } from '../app-form/app-form.component';

@Component({
  selector: 'app-app-grid',
  standalone: true,
  imports: [
    RouterLink, CommonModule,
    DxDataGridModule, DxButtonModule, DxPopupModule,
    DxLoadIndicatorModule, DxToastModule,
    AppFormComponent
  ],
  templateUrl: './app-grid.component.html',
  styleUrl: './app-grid.component.scss'
})
export class AppGridComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private api = inject(ApiService);

  slug = '';
  meta = signal<AppMetadata | null>(null);
  loading = signal(true);
  error = signal('');

  // Permission-aware UI flags (spec §6.4)
  showAddButton = computed(() => ['readwrite', 'owner', 'admin'].includes(this.meta()?.permission ?? ''));
  showEditButton = computed(() => ['readwrite', 'owner', 'admin'].includes(this.meta()?.permission ?? ''));
  showDeleteButton = computed(() => ['owner', 'admin'].includes(this.meta()?.permission ?? ''));
  showManageAccess = computed(() => ['owner', 'admin'].includes(this.meta()?.permission ?? ''));

  // DxDataGrid column config derived from metadata
  gridColumns = computed(() => {
    const cols = this.meta()?.columns ?? [];
    return cols.map(col => ({
      dataField: col.columnName,
      caption: col.displayName,
      dataType: TYPE_MAP[col.dataType]?.gridType ?? 'string',
      allowFiltering: col.isSearchable,
      allowSorting: true
    }));
  });

  // Data source backed by paged API calls
  dataSource: unknown[] = [];
  totalCount = 0;
  page = 1;
  pageSize = 50;

  // Form popup state
  formVisible = signal(false);
  editRowId = signal<number | null>(null);
  editRowData = signal<Record<string, unknown>>({});

  toastMessage = signal('');
  toastVisible = signal(false);

  ngOnInit() {
    this.slug = this.route.snapshot.paramMap.get('slug') ?? '';
    this.api.getMeta(this.slug).subscribe({
      next: meta => { this.meta.set(meta); this.loading.set(false); this.loadData(); },
      error: err => {
        this.error.set(err.status === 404 ? 'App not found or you do not have access.' : 'Failed to load app.');
        this.loading.set(false);
      }
    });
  }

  loadData(options: { page?: number; search?: string; sortField?: string; sortOrder?: string } = {}) {
    this.api.getRows(this.slug, {
      page: options.page ?? this.page,
      pageSize: this.pageSize,
      search: options.search,
      sortField: options.sortField,
      sortOrder: options.sortOrder
    }).subscribe({
      next: (result: PagedResult) => {
        this.dataSource = result.rows;
        this.totalCount = result.totalCount;
      }
    });
  }

  openAddForm() {
    this.editRowId.set(null);
    this.editRowData.set({});
    this.formVisible.set(true);
  }

  openEditForm(rowData: Record<string, unknown>) {
    this.editRowId.set(rowData['__id'] as number);
    this.editRowData.set({ ...rowData });
    this.formVisible.set(true);
  }

  deleteRow(rowData: Record<string, unknown>) {
    if (!confirm('Delete this row? This action is logged and cannot be undone.')) return;
    this.api.deleteRow(this.slug, rowData['__id'] as number).subscribe({
      next: () => { this.loadData(); this.showToast('Row deleted.'); },
      error: () => this.showToast('Failed to delete row.', true)
    });
  }

  onFormSaved() {
    this.formVisible.set(false);
    this.loadData();
    this.showToast(this.editRowId() ? 'Row updated.' : 'Row added.');
  }

  onPageChanged(page: number) {
    this.page = page;
    this.loadData({ page });
  }

  showToast(message: string, isError = false) {
    this.toastMessage.set(message);
    this.toastVisible.set(true);
  }

  // Extract columns for form (passed to AppFormComponent)
  get columns(): AppColumn[] {
    return this.meta()?.columns ?? [];
  }
}
