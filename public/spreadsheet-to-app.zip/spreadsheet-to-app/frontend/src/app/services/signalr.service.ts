import { Injectable } from '@angular/core';
import * as signalR from '@microsoft/signalr';

@Injectable({ providedIn: 'root' })
export class SignalRService {
  private connection: signalR.HubConnection;

  constructor() {
    this.connection = new signalR.HubConnectionBuilder()
      .withUrl('/hubs/import', {
        withCredentials: true   // required for Windows Auth
      })
      .withAutomaticReconnect()
      .configureLogging(signalR.LogLevel.Warning)
      .build();
  }

  start(): void {
    if (this.connection.state === signalR.HubConnectionState.Disconnected) {
      this.connection.start().catch(err => console.error('SignalR connection error:', err));
    }
  }

  stop(): void {
    this.connection.stop();
  }

  on(event: string, callback: (...args: unknown[]) => void): void {
    this.connection.on(event, callback);
  }

  off(event: string): void {
    this.connection.off(event);
  }

  get connectionId(): string | null {
    return this.connection.connectionId;
  }
}
