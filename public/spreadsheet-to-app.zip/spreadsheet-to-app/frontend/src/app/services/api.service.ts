import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  AppListItem, AppMetadata, InferredSchema,
  ConfirmImportRequest, PagedResult
} from '../models/app-meta.model';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private base = '/api';

  // ---- App metadata ----

  getApps(): Observable<AppListItem[]> {
    return this.http.get<AppListItem[]>(`${this.base}/apps`);
  }

  getMeta(slug: string): Observable<AppMetadata> {
    return this.http.get<AppMetadata>(`${this.base}/meta/${slug}`);
  }

  // ---- Upload & import ----

  uploadFile(file: File, sheetName?: string): Observable<InferredSchema> {
    const fd = new FormData();
    fd.append('file', file);
    if (sheetName) fd.append('sheetName', sheetName);
    return this.http.post<InferredSchema>(`${this.base}/apps/upload`, fd);
  }

  confirmImport(request: ConfirmImportRequest): Observable<{ slug: string; displayName: string; rowCount: number }> {
    return this.http.post<{ slug: string; displayName: string; rowCount: number }>(
      `${this.base}/apps/confirm`, request);
  }

  // ---- Schema management ----

  getSchema(slug: string): Observable<unknown> {
    return this.http.get(`${this.base}/apps/${slug}/schema`);
  }

  updateSchema(slug: string, changes: unknown): Observable<unknown> {
    return this.http.put(`${this.base}/apps/${slug}/schema`, changes);
  }

  deleteApp(slug: string): Observable<unknown> {
    return this.http.delete(`${this.base}/apps/${slug}`);
  }

  // ---- CRUD data ----

  getRows(slug: string, options: {
    page?: number;
    pageSize?: number;
    search?: string;
    sortField?: string;
    sortOrder?: string;
    filterField?: string;
    filterValue?: string;
  } = {}): Observable<PagedResult> {
    let params = new HttpParams();
    if (options.page)        params = params.set('page', options.page);
    if (options.pageSize)    params = params.set('pageSize', options.pageSize);
    if (options.search)      params = params.set('search', options.search);
    if (options.sortField)   params = params.set('sortField', options.sortField);
    if (options.sortOrder)   params = params.set('sortOrder', options.sortOrder);
    if (options.filterField) params = params.set('filterField', options.filterField);
    if (options.filterValue) params = params.set('filterValue', options.filterValue);
    return this.http.get<PagedResult>(`${this.base}/data/${slug}`, { params });
  }

  getRow(slug: string, id: number): Observable<Record<string, unknown>> {
    return this.http.get<Record<string, unknown>>(`${this.base}/data/${slug}/${id}`);
  }

  insertRow(slug: string, data: Record<string, unknown>): Observable<{ id: number }> {
    return this.http.post<{ id: number }>(`${this.base}/data/${slug}`, data);
  }

  updateRow(slug: string, id: number, data: Record<string, unknown>): Observable<unknown> {
    return this.http.put(`${this.base}/data/${slug}/${id}`, data);
  }

  deleteRow(slug: string, id: number): Observable<unknown> {
    return this.http.delete(`${this.base}/data/${slug}/${id}`);
  }

  // ---- Permissions ----

  getPermissions(slug: string): Observable<unknown[]> {
    return this.http.get<unknown[]>(`${this.base}/apps/${slug}/permissions`);
  }

  grantPermission(slug: string, username: string, permission: string): Observable<unknown> {
    return this.http.post(`${this.base}/apps/${slug}/permissions`, { username, permission });
  }

  revokePermission(slug: string, userId: number): Observable<unknown> {
    return this.http.delete(`${this.base}/apps/${slug}/permissions/${userId}`);
  }

  // ---- Admin ----

  adminGetApps(): Observable<unknown[]> {
    return this.http.get<unknown[]>(`${this.base}/admin/apps`);
  }

  adminGetUsers(): Observable<unknown[]> {
    return this.http.get<unknown[]>(`${this.base}/admin/users`);
  }

  adminUpdateUser(id: number, isAdmin: boolean, isActive: boolean): Observable<unknown> {
    return this.http.put(`${this.base}/admin/users/${id}`, { isAdmin, isActive });
  }

  adminGetAudit(filters: {
    appId?: number;
    changedBy?: string;
    from?: string;
    to?: string;
    action?: string;
    page?: number;
    pageSize?: number;
  }): Observable<unknown> {
    let params = new HttpParams();
    if (filters.appId)     params = params.set('appId', filters.appId);
    if (filters.changedBy) params = params.set('changedBy', filters.changedBy);
    if (filters.from)      params = params.set('from', filters.from);
    if (filters.to)        params = params.set('to', filters.to);
    if (filters.action)    params = params.set('action', filters.action);
    if (filters.page)      params = params.set('page', filters.page);
    if (filters.pageSize)  params = params.set('pageSize', filters.pageSize);
    return this.http.get(`${this.base}/admin/audit`, { params });
  }
}
