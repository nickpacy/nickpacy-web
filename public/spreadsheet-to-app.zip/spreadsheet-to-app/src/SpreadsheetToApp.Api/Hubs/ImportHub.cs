using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace SpreadsheetToApp.Api.Hubs;

[Authorize]
public class ImportHub : Hub
{
    // Clients connect to this hub to receive import progress events.
    // The server calls hub.Clients.User(userId).SendAsync("ImportProgress", ...) from ImportService.
    //
    // Angular connects via:
    //   const connection = new HubConnectionBuilder()
    //     .withUrl('/hubs/import', { withCredentials: true })
    //     .build();
    //   connection.on('ImportProgress', (data) => { ... });
    //   connection.on('ImportComplete', (data) => { ... });
    //   connection.on('ImportFailed', (data) => { ... });
}
