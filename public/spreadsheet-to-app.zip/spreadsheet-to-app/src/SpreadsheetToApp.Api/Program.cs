using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.Data.SqlClient;
using SpreadsheetToApp.Api.Hubs;
using SpreadsheetToApp.Api.Services;
using System.Data;

var builder = WebApplication.CreateBuilder(args);

// -------------------------------------------------------
// Authentication — Windows AD (Negotiate/Kerberos)
// No login screen, no passwords stored.
// -------------------------------------------------------
builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
    .AddNegotiate();

builder.Services.AddAuthorization();

// -------------------------------------------------------
// Database — scoped IDbConnection via Dapper
// -------------------------------------------------------
builder.Services.AddScoped<IDbConnection>(_ =>
    new SqlConnection(builder.Configuration.GetConnectionString("AppGenDB")));

// -------------------------------------------------------
// Application services
// -------------------------------------------------------
builder.Services.AddScoped<IRegistryService, RegistryService>();
builder.Services.AddScoped<ISchemaInferenceService, SchemaInferenceService>();
builder.Services.AddScoped<IImportService, ImportService>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<IPermissionService, PermissionService>();

// -------------------------------------------------------
// SignalR — import progress push
// -------------------------------------------------------
builder.Services.AddSignalR();

// -------------------------------------------------------
// Controllers + JSON
// -------------------------------------------------------
builder.Services.AddControllers()
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
    });

// -------------------------------------------------------
// CORS — allow Angular dev server in development
// -------------------------------------------------------
builder.Services.AddCors(options =>
{
    options.AddPolicy("AngularDev", policy =>
    {
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials(); // required for Windows Auth + SignalR
    });
});

// -------------------------------------------------------
// Ensure temp upload directory exists
// -------------------------------------------------------
var tempDir = builder.Configuration["Upload:TempDirectory"] ?? "uploads/temp";
Directory.CreateDirectory(tempDir);

var app = builder.Build();

app.UseHttpsRedirection();

app.UseCors("AngularDev");

app.UseAuthentication();
app.UseAuthorization();

// Serve Angular SPA from wwwroot in production
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapControllers();
app.MapHub<ImportHub>("/hubs/import");

// SPA fallback — all non-API routes go to Angular
app.MapFallbackToFile("index.html");

app.Run();
