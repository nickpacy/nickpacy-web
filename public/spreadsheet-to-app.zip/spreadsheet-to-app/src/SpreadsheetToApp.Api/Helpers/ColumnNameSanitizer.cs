using System.Text.RegularExpressions;

namespace SpreadsheetToApp.Api.Helpers;

public static partial class ColumnNameSanitizer
{
    [GeneratedRegex(@"[^a-zA-Z0-9_]")]
    private static partial Regex NonAlphanumericRegex();

    [GeneratedRegex(@"^\d")]
    private static partial Regex StartsWithDigitRegex();

    /// <summary>
    /// Sanitizes a raw column header into a safe SQL identifier.
    /// Rules (per spec §5.4 — hard rule, no exceptions):
    ///   1. Strip everything except alphanumeric and underscores
    ///   2. Names must start with a letter — prefix col_ if not
    ///   3. Max length 128 characters
    ///   4. SQL Server reserved words get a _col suffix
    /// </summary>
    public static string Sanitize(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
            return "col_unnamed";

        // 1. Strip non-alphanumeric/underscore characters
        var cleaned = NonAlphanumericRegex().Replace(raw.Trim(), "_");

        // 2. Must start with a letter
        if (StartsWithDigitRegex().IsMatch(cleaned))
            cleaned = "col_" + cleaned;

        // Edge case: entirely underscores after stripping
        if (cleaned.Replace("_", "").Length == 0)
            cleaned = "col_unnamed";

        // 3. Enforce max length
        if (cleaned.Length > 128)
            cleaned = cleaned[..128];

        // 4. Check against SQL Server reserved words
        if (SqlReservedWords.All.Contains(cleaned.ToUpperInvariant()))
            cleaned = cleaned + "_col";

        return cleaned;
    }

    /// <summary>
    /// Returns true if sanitizing raw produces a different string,
    /// indicating the column name was auto-renamed.
    /// </summary>
    public static bool WasRenamed(string raw, string sanitized)
        => !string.Equals(raw?.Trim(), sanitized, StringComparison.OrdinalIgnoreCase);
}
