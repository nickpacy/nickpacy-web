using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpreadsheetToApp.Api.Models;
using SpreadsheetToApp.Api.Services;
using System.Data;

namespace SpreadsheetToApp.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/admin")]
public class AdminController(
    IDbConnection db,
    IPermissionService permissions,
    IAuditService audit) : ControllerBase
{
    private string CurrentUser => User.Identity!.Name!;

    private async Task<bool> IsAdminAsync()
    {
        var user = await permissions.GetUserAsync(CurrentUser);
        return user?.IsAdmin == true;
    }

    // -------------------------------------------------------
    // GET /api/admin/apps
    // All apps including inactive (Admin only).
    // -------------------------------------------------------
    [HttpGet("apps")]
    public async Task<IActionResult> GetAllApps()
    {
        if (!await IsAdminAsync()) return Forbid();

        var apps = await db.QueryAsync<PlatformApp>(
            "SELECT * FROM platform_apps ORDER BY display_name");
        return Ok(apps);
    }

    // -------------------------------------------------------
    // GET /api/admin/users
    // All platform users (Admin only).
    // -------------------------------------------------------
    [HttpGet("users")]
    public async Task<IActionResult> GetAllUsers()
    {
        if (!await IsAdminAsync()) return Forbid();

        var users = await db.QueryAsync<PlatformUser>(
            "SELECT * FROM platform_users ORDER BY username");
        return Ok(users);
    }

    // -------------------------------------------------------
    // PUT /api/admin/users/:id
    // Update user — set is_admin flag (Admin only).
    // -------------------------------------------------------
    [HttpPut("users/{id:int}")]
    public async Task<IActionResult> UpdateUser(int id, [FromBody] UpdateUserRequest request)
    {
        if (!await IsAdminAsync()) return Forbid();

        await db.ExecuteAsync(
            "UPDATE platform_users SET is_admin = @isAdmin, is_active = @isActive WHERE id = @id",
            new { id, request.IsAdmin, request.IsActive });

        return Ok(new { message = "User updated." });
    }

    // -------------------------------------------------------
    // GET /api/admin/audit
    // Platform-wide audit search (Admin only).
    // -------------------------------------------------------
    [HttpGet("audit")]
    public async Task<IActionResult> SearchAudit(
        [FromQuery] int? appId,
        [FromQuery] string? changedBy,
        [FromQuery] DateTime? from,
        [FromQuery] DateTime? to,
        [FromQuery] string? action,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50)
    {
        if (!await IsAdminAsync()) return Forbid();

        var (rows, totalCount) = await audit.SearchAuditAsync(appId, changedBy, from, to, action, page, pageSize);
        return Ok(new { rows, totalCount, page, pageSize });
    }
}

public record UpdateUserRequest(bool IsAdmin, bool IsActive);
