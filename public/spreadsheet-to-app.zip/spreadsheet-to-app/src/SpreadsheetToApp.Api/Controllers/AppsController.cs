using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpreadsheetToApp.Api.Models;
using SpreadsheetToApp.Api.Services;
using System.Data;

namespace SpreadsheetToApp.Api.Controllers;

[ApiController]
[Authorize]
[Route("api")]
public class AppsController(
    IRegistryService registry,
    IImportService importService,
    IPermissionService permissions,
    IAuditService audit,
    IDbConnection db) : ControllerBase
{
    private string CurrentUser => User.Identity!.Name!;

    // -------------------------------------------------------
    // GET /api/apps
    // List all apps visible to the current user.
    // -------------------------------------------------------
    [HttpGet("apps")]
    public async Task<IActionResult> GetApps()
    {
        await permissions.EnsureUserRegisteredAsync(CurrentUser, User.Identity?.Name);
        var user = await permissions.GetUserAsync(CurrentUser);
        var apps = user?.IsAdmin == true
            ? await registry.GetAllAppsAsync()
            : await registry.GetAppsForUserAsync(CurrentUser);
        return Ok(apps);
    }

    // -------------------------------------------------------
    // GET /api/meta/:slug
    // Schema + columns + user's permission level.
    // -------------------------------------------------------
    [HttpGet("meta/{slug}")]
    public async Task<IActionResult> GetMeta(string slug)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        var columns = await registry.GetColumnsAsync(app.Id);

        return Ok(new AppMetadata
        {
            AppId = app.Id,
            Slug = app.Slug,
            DisplayName = app.DisplayName,
            Permission = permission,
            Columns = columns,
            RowCount = app.RowCount,
            ImportStrategy = app.ImportStrategy,
            UpsertKeyCol = app.UpsertKeyCol
        });
    }

    // -------------------------------------------------------
    // POST /api/apps/upload
    // Upload Excel file — runs inference, returns schema for review.
    // Nothing is written to the database at this stage.
    // -------------------------------------------------------
    [HttpPost("apps/upload")]
    public async Task<IActionResult> Upload([FromForm] IFormFile file, [FromForm] string? sheetName)
    {
        await permissions.EnsureUserRegisteredAsync(CurrentUser, User.Identity?.Name);

        try
        {
            var schema = await importService.UploadAndInferAsync(file, CurrentUser);
            if (!string.IsNullOrEmpty(sheetName) && schema.SheetNames.Contains(sheetName))
            {
                // Re-infer on the requested sheet if different from default
                schema.SelectedSheet = sheetName;
            }
            return Ok(schema);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    // -------------------------------------------------------
    // POST /api/apps/confirm
    // Confirm reviewed schema, create table, import data.
    // -------------------------------------------------------
    [HttpPost("apps/confirm")]
    public async Task<IActionResult> Confirm([FromBody] ConfirmImportRequest request)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);

        var connectionId = Request.Headers["X-SignalR-ConnectionId"].FirstOrDefault() ?? string.Empty;

        try
        {
            var app = await importService.ConfirmImportAsync(request, CurrentUser, connectionId);
            return Ok(new { app.Slug, app.DisplayName, app.RowCount });
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    // -------------------------------------------------------
    // GET /api/apps/:slug/schema
    // Current schema for the edit schema screen (Owner/Admin).
    // -------------------------------------------------------
    [HttpGet("apps/{slug}/schema")]
    public async Task<IActionResult> GetSchema(string slug)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();
        if (!IsOwnerOrAdmin(permission)) return Forbid();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        var columns = await registry.GetColumnsAsync(app.Id);
        return Ok(new { app, columns });
    }

    // -------------------------------------------------------
    // PUT /api/apps/:slug/schema
    // Apply schema changes (Owner/Admin).
    // -------------------------------------------------------
    [HttpPut("apps/{slug}/schema")]
    public async Task<IActionResult> UpdateSchema(string slug, [FromBody] SchemaEditRequest request)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();
        if (!IsOwnerOrAdmin(permission)) return Forbid();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        foreach (var change in request.Changes)
        {
            if (change.Delete)
            {
                await db.ExecuteAsync(
                    "UPDATE platform_columns SET is_active = 0, deleted_at = GETDATE() WHERE id = @id AND app_id = @appId",
                    new { id = change.ColumnId, appId = app.Id });

                await audit.LogSchemaChangeAsync(app.Id, app.TableName,
                    $"Column {change.ColumnId} soft-deleted", CurrentUser);
                continue;
            }

            var updates = new List<string>();
            var p = new DynamicParameters();
            p.Add("id", change.ColumnId);
            p.Add("appId", app.Id);

            if (change.NewDisplayName != null) { updates.Add("display_name = @displayName"); p.Add("displayName", change.NewDisplayName); }
            if (change.NewIsRequired.HasValue) { updates.Add("is_required = @isRequired"); p.Add("isRequired", change.NewIsRequired); }
            if (change.NewIsSearchable.HasValue) { updates.Add("is_searchable = @isSearchable"); p.Add("isSearchable", change.NewIsSearchable); }
            if (change.NewColumnOrder.HasValue) { updates.Add("column_order = @columnOrder"); p.Add("columnOrder", change.NewColumnOrder); }

            if (updates.Count > 0)
            {
                await db.ExecuteAsync(
                    $"UPDATE platform_columns SET {string.Join(", ", updates)} WHERE id = @id AND app_id = @appId",
                    p);
            }

            // Data type changes require separate validation — see §8.3
            if (change.NewDataType != null)
            {
                // TODO: validate existing data for type conflicts before altering
                await db.ExecuteAsync(
                    "UPDATE platform_columns SET data_type = @dataType, max_length = @maxLength WHERE id = @id AND app_id = @appId",
                    new { dataType = change.NewDataType, maxLength = change.NewMaxLength, id = change.ColumnId, appId = app.Id });

                await audit.LogSchemaChangeAsync(app.Id, app.TableName,
                    $"Column {change.ColumnId} type changed to {change.NewDataType}", CurrentUser);
            }
        }

        return Ok(new { message = "Schema updated." });
    }

    // -------------------------------------------------------
    // DELETE /api/apps/:slug
    // Soft delete an app (Owner/Admin).
    // -------------------------------------------------------
    [HttpDelete("apps/{slug}")]
    public async Task<IActionResult> DeleteApp(string slug)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();
        if (!IsOwnerOrAdmin(permission)) return Forbid();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        await registry.SoftDeleteAppAsync(app.Id, CurrentUser);
        await audit.LogSchemaChangeAsync(app.Id, app.TableName, "App soft-deleted", CurrentUser);
        return Ok(new { message = "App deleted." });
    }

    // -------------------------------------------------------
    // GET /api/apps/:slug/permissions
    // List app members (Owner/Admin).
    // -------------------------------------------------------
    [HttpGet("apps/{slug}/permissions")]
    public async Task<IActionResult> GetPermissions(string slug)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();
        if (!IsOwnerOrAdmin(permission)) return Forbid();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        var perms = await permissions.GetAppPermissionsAsync(app.Id);
        return Ok(perms);
    }

    // -------------------------------------------------------
    // POST /api/apps/:slug/permissions
    // Grant user access to app (Owner/Admin).
    // -------------------------------------------------------
    [HttpPost("apps/{slug}/permissions")]
    public async Task<IActionResult> GrantPermission(string slug, [FromBody] GrantPermissionRequest request)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();
        if (!IsOwnerOrAdmin(permission)) return Forbid();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        var targetUser = await permissions.GetUserAsync(request.Username);
        if (targetUser == null) return BadRequest(new { error = "User not found. They must log in to the platform first." });

        await permissions.GrantPermissionAsync(app.Id, targetUser.Id, request.Permission, CurrentUser);
        return Ok(new { message = $"Permission '{request.Permission}' granted to {request.Username}." });
    }

    // -------------------------------------------------------
    // DELETE /api/apps/:slug/permissions/:userId
    // Revoke user access (Owner/Admin).
    // -------------------------------------------------------
    [HttpDelete("apps/{slug}/permissions/{userId:int}")]
    public async Task<IActionResult> RevokePermission(string slug, int userId)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();
        if (!IsOwnerOrAdmin(permission)) return Forbid();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        await permissions.RevokePermissionAsync(app.Id, userId);
        return Ok(new { message = "Permission revoked." });
    }

    private static bool IsOwnerOrAdmin(string permission)
        => permission is PermissionLevel.Owner or PermissionLevel.Admin;
}

public record GrantPermissionRequest(string Username, string Permission);
