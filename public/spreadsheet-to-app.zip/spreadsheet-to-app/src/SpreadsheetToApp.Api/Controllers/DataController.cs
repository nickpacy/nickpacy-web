using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpreadsheetToApp.Api.Models;
using SpreadsheetToApp.Api.Services;
using System.Data;
using System.Text.Json;

namespace SpreadsheetToApp.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/data")]
public class DataController(
    IDbConnection db,
    IRegistryService registry,
    IPermissionService permissions,
    IAuditService audit) : ControllerBase
{
    private string CurrentUser => User.Identity!.Name!;
    private string ClientIp => HttpContext.Connection.RemoteIpAddress?.ToString() ?? string.Empty;

    // -------------------------------------------------------
    // GET /api/data/:slug
    // Paginated rows — supports sort, filter, search params.
    //
    // SECURITY: Table and column names from REGISTRY only.
    //           User filter values use DynamicParameters.
    // -------------------------------------------------------
    [HttpGet("{slug}")]
    public async Task<IActionResult> GetRows(
        string slug,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50,
        [FromQuery] string? search = null,
        [FromQuery] string? sortField = null,
        [FromQuery] string? sortOrder = null,
        [FromQuery] string? filterField = null,
        [FromQuery] string? filterValue = null)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        // All column names come from the registry — never from user input
        var columns = await registry.GetColumnsAsync(app.Id);
        var searchableColumns = columns.Where(c => c.IsSearchable).ToList();

        // Build SELECT with bracket-wrapped column names from registry
        var colList = string.Join(", ", columns.Select(c => $"[{c.ColumnName}]"));
        var sql = $"SELECT [__id], {colList} FROM [{app.TableName}] WHERE 1=1";

        var parameters = new DynamicParameters();

        // Global search — LIKE across all searchable NVARCHAR columns
        if (!string.IsNullOrWhiteSpace(search) && searchableColumns.Count > 0)
        {
            var searchClauses = searchableColumns
                .Where(c => c.DataType == "NVARCHAR")
                .Select((c, i) => $"[{c.ColumnName}] LIKE @search{i}");
            if (searchClauses.Any())
            {
                sql += $" AND ({string.Join(" OR ", searchClauses)})";
                var idx = 0;
                foreach (var _ in searchableColumns.Where(c => c.DataType == "NVARCHAR"))
                    parameters.Add($"search{idx++}", $"%{search}%");
            }
        }

        // Column-level filter (from DxDataGrid filter row)
        if (!string.IsNullOrWhiteSpace(filterField) && !string.IsNullOrWhiteSpace(filterValue))
        {
            // Validate filterField is a real column name from registry — not from user input
            var col = columns.FirstOrDefault(c => c.ColumnName == filterField);
            if (col != null)
            {
                sql += $" AND [{col.ColumnName}] LIKE @filterValue";
                parameters.Add("filterValue", $"%{filterValue}%");
            }
        }

        // COUNT for pagination
        var countSql = sql.Replace($"SELECT [__id], {colList}", "SELECT COUNT(*)");
        var totalCount = await db.QuerySingleAsync<int>(countSql, parameters);

        // Sort — column name validated against registry
        if (!string.IsNullOrWhiteSpace(sortField))
        {
            var sortCol = columns.FirstOrDefault(c => c.ColumnName == sortField);
            if (sortCol != null)
            {
                var direction = sortOrder?.ToLowerInvariant() == "desc" ? "DESC" : "ASC";
                sql += $" ORDER BY [{sortCol.ColumnName}] {direction}";
            }
            else
            {
                sql += " ORDER BY [__id] ASC";
            }
        }
        else
        {
            sql += " ORDER BY [__id] ASC";
        }

        sql += " OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY";
        parameters.Add("offset", (page - 1) * pageSize);
        parameters.Add("pageSize", pageSize);

        var rows = await db.QueryAsync(sql, parameters);

        return Ok(new PagedResult
        {
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize,
            Rows = rows
        });
    }

    // -------------------------------------------------------
    // GET /api/data/:slug/:id
    // Single row by __id.
    // -------------------------------------------------------
    [HttpGet("{slug}/{id:int}")]
    public async Task<IActionResult> GetRow(string slug, int id)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        var columns = await registry.GetColumnsAsync(app.Id);
        var colList = string.Join(", ", columns.Select(c => $"[{c.ColumnName}]"));
        var sql = $"SELECT [__id], {colList} FROM [{app.TableName}] WHERE [__id] = @id";

        var row = await db.QueryFirstOrDefaultAsync(sql, new { id });
        if (row == null) return NotFound();

        return Ok(row);
    }

    // -------------------------------------------------------
    // POST /api/data/:slug
    // Insert new row — ReadWrite+.
    // -------------------------------------------------------
    [HttpPost("{slug}")]
    public async Task<IActionResult> InsertRow(string slug, [FromBody] Dictionary<string, JsonElement> body)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();
        if (!CanWrite(permission)) return Forbid();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        var columns = await registry.GetColumnsAsync(app.Id);
        var parameters = new DynamicParameters();
        parameters.Add("createdBy", CurrentUser);

        foreach (var col in columns)
        {
            if (body.TryGetValue(col.ColumnName, out var element))
                parameters.Add(col.ColumnName, element.ToString());
            else if (col.IsRequired)
                return BadRequest(new { error = $"Required field '{col.DisplayName}' is missing." });
            else
                parameters.Add(col.ColumnName, null);
        }

        var colNames = string.Join(", ", columns.Select(c => $"[{c.ColumnName}]"));
        var paramNames = string.Join(", ", columns.Select(c => $"@{c.ColumnName}"));
        var sql = $"INSERT INTO [{app.TableName}] ([__created_by], {colNames}) VALUES (@createdBy, {paramNames}); SELECT SCOPE_IDENTITY();";

        var newId = await db.QuerySingleAsync<int>(sql, parameters);
        await audit.LogInsertAsync(app.Id, app.TableName, newId, CurrentUser, ClientIp);

        return Ok(new { id = newId });
    }

    // -------------------------------------------------------
    // PUT /api/data/:slug/:id
    // Update row — ReadWrite+.
    // -------------------------------------------------------
    [HttpPut("{slug}/{id:int}")]
    public async Task<IActionResult> UpdateRow(string slug, int id, [FromBody] Dictionary<string, JsonElement> body)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();
        if (!CanWrite(permission)) return Forbid();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        var columns = await registry.GetColumnsAsync(app.Id);

        // Fetch existing row for audit diff
        var colList = string.Join(", ", columns.Select(c => $"[{c.ColumnName}]"));
        var existing = await db.QueryFirstOrDefaultAsync(
            $"SELECT {colList} FROM [{app.TableName}] WHERE [__id] = @id",
            new { id }) as IDictionary<string, object?>;

        if (existing == null) return NotFound();

        var setClauses = new List<string>();
        var parameters = new DynamicParameters();
        parameters.Add("id", id);
        parameters.Add("modifiedBy", CurrentUser);
        var changedFields = new Dictionary<string, (string? OldValue, string? NewValue)>();

        foreach (var col in columns)
        {
            if (!body.ContainsKey(col.ColumnName)) continue;
            var newVal = body[col.ColumnName].ToString();
            var oldVal = existing.TryGetValue(col.ColumnName, out var ov) ? ov?.ToString() : null;

            setClauses.Add($"[{col.ColumnName}] = @{col.ColumnName}");
            parameters.Add(col.ColumnName, newVal);

            if (oldVal != newVal)
                changedFields[col.ColumnName] = (oldVal, newVal);
        }

        if (setClauses.Count == 0) return Ok(new { message = "No changes." });

        var sql = $"UPDATE [{app.TableName}] SET {string.Join(", ", setClauses)}, [__modified_by] = @modifiedBy, [__modified_at] = GETDATE() WHERE [__id] = @id";
        await db.ExecuteAsync(sql, parameters);

        if (changedFields.Count > 0)
            await audit.LogUpdateAsync(app.Id, app.TableName, id, CurrentUser, changedFields, ClientIp);

        return Ok(new { message = "Updated." });
    }

    // -------------------------------------------------------
    // DELETE /api/data/:slug/:id
    // Delete row — Owner/Admin only.
    // -------------------------------------------------------
    [HttpDelete("{slug}/{id:int}")]
    public async Task<IActionResult> DeleteRow(string slug, int id)
    {
        var permission = await permissions.GetPermissionAsync(CurrentUser, slug);
        if (permission == null) return NotFound();
        if (!CanDelete(permission)) return Forbid();

        var app = await registry.GetAppAsync(slug);
        if (app == null) return NotFound();

        var columns = await registry.GetColumnsAsync(app.Id);
        var colList = string.Join(", ", columns.Select(c => $"[{c.ColumnName}]"));

        // Snapshot for audit
        var snapshot = await db.QueryFirstOrDefaultAsync(
            $"SELECT {colList} FROM [{app.TableName}] WHERE [__id] = @id",
            new { id }) as IDictionary<string, object?>;

        if (snapshot == null) return NotFound();

        await db.ExecuteAsync($"DELETE FROM [{app.TableName}] WHERE [__id] = @id", new { id });

        var snapshotDict = snapshot.ToDictionary(k => k.Key, v => v.Value?.ToString());
        await audit.LogDeleteAsync(app.Id, app.TableName, id, CurrentUser, snapshotDict, ClientIp);

        return Ok(new { message = "Deleted." });
    }

    private static bool CanWrite(string permission)
        => permission is PermissionLevel.ReadWrite or PermissionLevel.Owner or PermissionLevel.Admin;

    private static bool CanDelete(string permission)
        => permission is PermissionLevel.Owner or PermissionLevel.Admin;
}
