using Dapper;
using SpreadsheetToApp.Api.Models;
using System.Data;

namespace SpreadsheetToApp.Api.Services;

public class RegistryService(IDbConnection db) : IRegistryService
{
    public async Task<PlatformApp?> GetAppAsync(string slug)
    {
        return await db.QueryFirstOrDefaultAsync<PlatformApp>(
            "SELECT * FROM platform_apps WHERE slug = @slug AND is_active = 1 AND deleted_at IS NULL",
            new { slug });
    }

    public async Task<PlatformApp?> GetAppByIdAsync(int id)
    {
        return await db.QueryFirstOrDefaultAsync<PlatformApp>(
            "SELECT * FROM platform_apps WHERE id = @id",
            new { id });
    }

    public async Task<List<PlatformColumn>> GetColumnsAsync(int appId)
    {
        var rows = await db.QueryAsync<PlatformColumn>(@"
            SELECT * FROM platform_columns
            WHERE app_id = @appId AND is_active = 1 AND deleted_at IS NULL
            ORDER BY column_order",
            new { appId });
        return rows.ToList();
    }

    public async Task<List<AppListItem>> GetAppsForUserAsync(string username)
    {
        var rows = await db.QueryAsync<AppListItem>(@"
            SELECT
                a.id, a.slug, a.display_name, a.row_count, a.created_at, a.created_by,
                CASE WHEN u.is_admin = 1 THEN 'admin' ELSE p.permission END AS permission
            FROM platform_apps a
            JOIN platform_users u ON u.username = @username AND u.is_active = 1
            LEFT JOIN platform_app_permissions p ON p.app_id = a.id AND p.user_id = u.id
            WHERE a.is_active = 1 AND a.deleted_at IS NULL
              AND (u.is_admin = 1 OR p.permission IS NOT NULL)
            ORDER BY a.display_name",
            new { username });
        return rows.ToList();
    }

    public async Task<List<AppListItem>> GetAllAppsAsync()
    {
        var rows = await db.QueryAsync<AppListItem>(@"
            SELECT id, slug, display_name, row_count, created_at, created_by, 'admin' AS permission
            FROM platform_apps
            ORDER BY display_name");
        return rows.ToList();
    }

    public async Task<int> CreateAppAsync(PlatformApp app)
    {
        return await db.QuerySingleAsync<int>(@"
            INSERT INTO platform_apps (slug, display_name, table_name, import_strategy, upsert_key_col, created_by)
            VALUES (@Slug, @DisplayName, @TableName, @ImportStrategy, @UpsertKeyCol, @CreatedBy);
            SELECT SCOPE_IDENTITY();",
            app);
    }

    public async Task<List<int>> CreateColumnsAsync(int appId, IEnumerable<InferredColumn> columns)
    {
        var ids = new List<int>();
        foreach (var col in columns)
        {
            var id = await db.QuerySingleAsync<int>(@"
                INSERT INTO platform_columns
                    (app_id, column_name, display_name, data_type, max_length, is_required, is_searchable, column_order)
                VALUES
                    (@appId, @columnName, @displayName, @dataType, @maxLength, @isRequired, @isSearchable, @columnOrder);
                SELECT SCOPE_IDENTITY();",
                new
                {
                    appId,
                    col.ColumnName,
                    col.DisplayName,
                    col.DataType,
                    col.MaxLength,
                    col.IsRequired,
                    col.IsSearchable,
                    col.ColumnOrder
                });
            ids.Add(id);
        }
        return ids;
    }

    public async Task UpdateRowCountAsync(int appId, int count)
    {
        await db.ExecuteAsync(
            "UPDATE platform_apps SET row_count = @count WHERE id = @appId",
            new { appId, count });
    }

    public async Task SoftDeleteAppAsync(int appId, string deletedBy)
    {
        await db.ExecuteAsync(
            "UPDATE platform_apps SET is_active = 0, deleted_at = GETDATE() WHERE id = @appId",
            new { appId });
    }
}
