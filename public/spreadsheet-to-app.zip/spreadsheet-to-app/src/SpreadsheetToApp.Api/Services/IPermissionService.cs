using SpreadsheetToApp.Api.Models;

namespace SpreadsheetToApp.Api.Services;

public interface IPermissionService
{
    /// <summary>
    /// Ensures the user exists in platform_users (upsert on first login).
    /// </summary>
    Task EnsureUserRegisteredAsync(string username, string? displayName);

    /// <summary>
    /// Returns the user's effective permission level for an app,
    /// or null if they have no access (should result in 404).
    /// Admins always receive "admin".
    /// </summary>
    Task<string?> GetPermissionAsync(string username, string appSlug);

    /// <summary>
    /// Returns the full PlatformUser record for a username, or null if not found.
    /// </summary>
    Task<PlatformUser?> GetUserAsync(string username);

    Task GrantPermissionAsync(int appId, int userId, string permission, string grantedByUsername);
    Task RevokePermissionAsync(int appId, int userId);
    Task<List<PlatformAppPermission>> GetAppPermissionsAsync(int appId);
}
