using ClosedXML.Excel;
using Dapper;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Data.SqlClient;
using SpreadsheetToApp.Api.Helpers;
using SpreadsheetToApp.Api.Hubs;
using SpreadsheetToApp.Api.Models;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;

namespace SpreadsheetToApp.Api.Services;

public class ImportService(
    IDbConnection db,
    IConfiguration config,
    ISchemaInferenceService inferenceService,
    IRegistryService registry,
    IPermissionService permissions,
    IHubContext<ImportHub> hub) : IImportService
{
    private static readonly string[] AllowedMimeTypes = [
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/octet-stream"
    ];

    public async Task<InferredSchema> UploadAndInferAsync(IFormFile file, string uploaderUsername)
    {
        // Layer 1: MIME type check
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (ext != ".xlsx")
            throw new InvalidOperationException("Only .xlsx files are accepted.");

        // Layer 2: File size check
        var maxBytes = config.GetValue<long>("Upload:MaxFileSizeBytes", 26_214_400);
        if (file.Length > maxBytes)
            throw new InvalidOperationException($"File exceeds maximum allowed size of {maxBytes / 1_048_576}MB.");

        // Save to temp directory
        var tempDir = config["Upload:TempDirectory"] ?? "uploads/temp";
        var tempId = Guid.NewGuid().ToString("N");
        var tempPath = Path.Combine(tempDir, $"{tempId}.xlsx");

        await using (var stream = File.Create(tempPath))
            await file.CopyToAsync(stream);

        // Layer 3: Validate with ClosedXML (catches corrupt/non-xlsx files)
        List<string> sheetNames;
        try
        {
            sheetNames = inferenceService.GetSheetNames(tempPath);
        }
        catch
        {
            File.Delete(tempPath);
            throw new InvalidOperationException("File could not be opened. It may be corrupt or not a valid Excel file.");
        }

        if (sheetNames.Count == 0)
        {
            File.Delete(tempPath);
            throw new InvalidOperationException("Excel file contains no worksheets.");
        }

        var selectedSheet = sheetNames[0];
        var schema = inferenceService.InferSchema(tempPath, selectedSheet);
        schema.TempFileId = tempId;
        schema.OriginalFileName = file.FileName;
        schema.SheetNames = sheetNames;
        schema.SelectedSheet = selectedSheet;

        return schema;
    }

    public async Task<PlatformApp> ConfirmImportAsync(
        ConfirmImportRequest request, string uploaderUsername, string connectionId)
    {
        var tempDir = config["Upload:TempDirectory"] ?? "uploads/temp";
        var tempPath = Path.Combine(tempDir, $"{request.TempFileId}.xlsx");

        if (!File.Exists(tempPath))
            throw new InvalidOperationException("Uploaded file no longer exists. Please upload again.");

        // Slug uniqueness check
        var existing = await registry.GetAppAsync(request.AppSlug);
        var isNewApp = existing == null;

        // Generate unique table name: app_{slug}_{shortid}
        var shortId = request.TempFileId[..4];
        var tableName = isNewApp
            ? $"app_{SanitizeSlug(request.AppSlug)}_{shortId}"
            : existing!.TableName;

        // Active columns only (user may have excluded some)
        var activeColumns = request.Columns.Where(c => !c.Exclude).ToList();

        // The entire pipeline runs in a single transaction
        using var sqlConn = new SqlConnection(config.GetConnectionString("AppGenDB"));
        await sqlConn.OpenAsync();
        using var transaction = sqlConn.BeginTransaction();

        try
        {
            int appId;
            PlatformApp app;

            if (isNewApp)
            {
                // 1. Create app registry entry
                app = new PlatformApp
                {
                    Slug = request.AppSlug,
                    DisplayName = request.DisplayName,
                    TableName = tableName,
                    ImportStrategy = request.ImportStrategy,
                    UpsertKeyCol = request.UpsertKeyCol,
                    CreatedBy = uploaderUsername
                };

                appId = await sqlConn.QuerySingleAsync<int>(@"
                    INSERT INTO platform_apps (slug, display_name, table_name, import_strategy, upsert_key_col, created_by)
                    VALUES (@Slug, @DisplayName, @TableName, @ImportStrategy, @UpsertKeyCol, @CreatedBy);
                    SELECT SCOPE_IDENTITY();",
                    app, transaction);

                app.Id = appId;

                // 2. Create column metadata
                var colOrder = 0;
                foreach (var col in activeColumns)
                {
                    col.ColumnOrder = colOrder++;
                    await sqlConn.ExecuteAsync(@"
                        INSERT INTO platform_columns
                            (app_id, column_name, display_name, data_type, max_length, is_required, is_searchable, column_order)
                        VALUES
                            (@appId, @ColumnName, @DisplayName, @DataType, @MaxLength, @IsRequired, @IsSearchable, @ColumnOrder)",
                        new { appId, col.ColumnName, col.DisplayName, col.DataType, col.MaxLength, col.IsRequired, col.IsSearchable, col.ColumnOrder },
                        transaction);
                }

                // 3. Create the SQL table
                var createSql = BuildCreateTableSql(tableName, activeColumns);
                await sqlConn.ExecuteAsync(createSql, transaction: transaction);

                // 4. Grant owner permission to uploader
                var userId = await sqlConn.QuerySingleAsync<int?>(@"
                    SELECT id FROM platform_users WHERE username = @uploaderUsername",
                    new { uploaderUsername }, transaction);

                if (userId.HasValue)
                {
                    await sqlConn.ExecuteAsync(@"
                        INSERT INTO platform_app_permissions (app_id, user_id, permission, granted_by)
                        VALUES (@appId, @userId, 'owner', @userId)",
                        new { appId, userId }, transaction);
                }
            }
            else
            {
                appId = existing!.Id;
                app = existing;
                await UpdateImportStrategy(sqlConn, transaction, appId, request.ImportStrategy, request.UpsertKeyCol);
            }

            // 5. Import rows
            var rowCount = await ImportRowsAsync(sqlConn, transaction, tempPath,
                request.SelectedSheet, tableName, activeColumns,
                request.ImportStrategy, request.UpsertKeyCol,
                appId, uploaderUsername, connectionId);

            // 6. Update row count in registry
            await sqlConn.ExecuteAsync(
                "UPDATE platform_apps SET row_count = @rowCount WHERE id = @appId",
                new { rowCount, appId }, transaction);

            transaction.Commit();

            // Clean up temp file
            File.Delete(tempPath);

            app.RowCount = rowCount;
            return app;
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    private static async Task UpdateImportStrategy(SqlConnection conn, SqlTransaction tx, int appId, string strategy, string? upsertKey)
    {
        await conn.ExecuteAsync(
            "UPDATE platform_apps SET import_strategy = @strategy, upsert_key_col = @upsertKey WHERE id = @appId",
            new { strategy, upsertKey, appId }, tx);
    }

    private async Task<int> ImportRowsAsync(
        SqlConnection conn, SqlTransaction tx,
        string filePath, string sheetName, string tableName,
        List<InferredColumn> columns, string strategy, string? upsertKeyCol,
        int appId, string username, string connectionId)
    {
        using var wb = new XLWorkbook(filePath);
        var ws = wb.Worksheet(sheetName);
        var usedRange = ws.RangeUsed();
        if (usedRange == null) return 0;

        var totalRows = usedRange.RowCount() - 1;

        // Strategy: replace = truncate first
        if (strategy == "replace")
            await conn.ExecuteAsync($"TRUNCATE TABLE [{tableName}]", transaction: tx);

        // Build header → column name map from first row
        var headerMap = new Dictionary<int, InferredColumn>();
        var firstRow = usedRange.FirstRow();
        foreach (var cell in firstRow.Cells())
        {
            var raw = cell.GetString().Trim();
            var sanitized = ColumnNameSanitizer.Sanitize(raw);
            var col = columns.FirstOrDefault(c => c.ColumnName == sanitized);
            if (col != null)
                headerMap[cell.Address.ColumnNumber] = col;
        }

        var colNames = columns.Select(c => $"[{c.ColumnName}]").ToList();
        var paramNames = columns.Select(c => $"@{c.ColumnName}").ToList();
        var insertSql = $"INSERT INTO [{tableName}] ([__created_by], {string.Join(", ", colNames)}) VALUES (@createdBy, {string.Join(", ", paramNames)})";

        var rowsProcessed = 0;

        for (var rowNum = 2; rowNum <= usedRange.RowCount(); rowNum++)
        {
            var parameters = new DynamicParameters();
            parameters.Add("createdBy", username);

            foreach (var (colNum, col) in headerMap)
            {
                var cell = ws.Cell(usedRange.FirstRow().RowNumber() + rowNum - 1, colNum);
                var rawVal = cell.GetString().Trim();
                object? typedVal = ConvertValue(rawVal, col.DataType);
                parameters.Add(col.ColumnName, typedVal);
            }

            if (strategy == "upsert" && !string.IsNullOrEmpty(upsertKeyCol))
                await UpsertRowAsync(conn, tx, tableName, columns, parameters, upsertKeyCol, username);
            else
                await conn.ExecuteAsync(insertSql, parameters, transaction: tx);

            rowsProcessed++;

            // Emit progress every 100 rows
            if (rowsProcessed % 100 == 0 || rowsProcessed == totalRows)
            {
                await hub.Clients.User(username).SendAsync("ImportProgress", new
                {
                    stage = "Importing rows",
                    current = rowsProcessed,
                    total = totalRows,
                    percent = totalRows > 0 ? rowsProcessed * 100 / totalRows : 100
                });
            }
        }

        return rowsProcessed;
    }

    private static async Task UpsertRowAsync(SqlConnection conn, SqlTransaction tx,
        string tableName, List<InferredColumn> columns,
        DynamicParameters parameters, string upsertKeyCol, string username)
    {
        var nonKeyColumns = columns.Where(c => c.ColumnName != upsertKeyCol).ToList();
        var updateClause = string.Join(", ", nonKeyColumns.Select(c => $"[{c.ColumnName}] = @{c.ColumnName}"));

        var upsertSql = $@"
            IF EXISTS (SELECT 1 FROM [{tableName}] WHERE [{upsertKeyCol}] = @{upsertKeyCol})
                UPDATE [{tableName}]
                SET {updateClause}, [__modified_by] = @createdBy, [__modified_at] = GETDATE()
                WHERE [{upsertKeyCol}] = @{upsertKeyCol}
            ELSE
                INSERT INTO [{tableName}] ([__created_by], {string.Join(", ", columns.Select(c => $"[{c.ColumnName}]"))})
                VALUES (@createdBy, {string.Join(", ", columns.Select(c => $"@{c.ColumnName}"))})";

        await conn.ExecuteAsync(upsertSql, parameters, transaction: tx);
    }

    private static string BuildCreateTableSql(string tableName, List<InferredColumn> columns)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"CREATE TABLE [{tableName}] (");
        sb.AppendLine("    [__id]          INT           IDENTITY PRIMARY KEY,");
        sb.AppendLine("    [__created_by]  VARCHAR(100)  NOT NULL,");
        sb.AppendLine("    [__created_at]  DATETIME      DEFAULT GETDATE(),");
        sb.AppendLine("    [__modified_by] VARCHAR(100)  NULL,");
        sb.AppendLine("    [__modified_at] DATETIME      NULL,");

        for (var i = 0; i < columns.Count; i++)
        {
            var col = columns[i];
            var typeDef = BuildColumnTypeSql(col);
            var nullable = col.IsRequired ? "NOT NULL" : "NULL";
            var comma = i < columns.Count - 1 ? "," : "";
            sb.AppendLine($"    [{col.ColumnName}] {typeDef} {nullable}{comma}");
        }

        sb.AppendLine(");");
        return sb.ToString();
    }

    private static string BuildColumnTypeSql(InferredColumn col)
    {
        return col.DataType switch
        {
            "INT" => "INT",
            "DECIMAL" => "DECIMAL(18, 4)",
            "DATE" => "DATE",
            "DATETIME" => "DATETIME",
            "BIT" => "BIT",
            "NVARCHAR" => col.MaxLength == -1
                ? "NVARCHAR(MAX)"
                : $"NVARCHAR({col.MaxLength ?? 255})",
            _ => "NVARCHAR(255)"
        };
    }

    private static object? ConvertValue(string raw, string dataType)
    {
        if (string.IsNullOrWhiteSpace(raw)) return null;
        return dataType switch
        {
            "INT" => int.TryParse(raw, out var i) ? i : (object?)null,
            "DECIMAL" => decimal.TryParse(raw, out var d) ? d : (object?)null,
            "DATE" or "DATETIME" => DateTime.TryParse(raw, out var dt) ? dt : (object?)null,
            "BIT" => raw.ToLowerInvariant() is "true" or "yes" or "1" or "y" ? true
                    : raw.ToLowerInvariant() is "false" or "no" or "0" or "n" ? false
                    : (object?)null,
            _ => raw
        };
    }

    private static string SanitizeSlug(string slug)
    {
        var s = Regex.Replace(slug.ToLowerInvariant(), @"[^a-z0-9_]", "_");
        return s.Length > 50 ? s[..50] : s;
    }
}
