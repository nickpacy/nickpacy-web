using SpreadsheetToApp.Api.Models;

namespace SpreadsheetToApp.Api.Services;

public interface IImportService
{
    /// <summary>
    /// Saves the uploaded file to a temp directory and runs schema inference.
    /// Returns the inferred schema for user review — nothing is written to the DB yet.
    /// </summary>
    Task<InferredSchema> UploadAndInferAsync(IFormFile file, string uploaderUsername);

    /// <summary>
    /// After user reviews and confirms the schema, this method:
    ///   1. Creates the SQL Server table
    ///   2. Writes registry metadata (platform_apps + platform_columns)
    ///   3. Imports all rows using the selected strategy
    ///   4. Grants the uploader "owner" permission
    ///   5. Emits SignalR progress events during import
    /// Everything runs inside a single SqlTransaction — partial states are impossible.
    /// </summary>
    Task<PlatformApp> ConfirmImportAsync(ConfirmImportRequest request, string uploaderUsername, string connectionId);
}
