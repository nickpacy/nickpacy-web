using SpreadsheetToApp.Api.Models;

namespace SpreadsheetToApp.Api.Services;

public interface IAuditService
{
    Task LogInsertAsync(int appId, string tableName, int recordId, string changedBy, string? ipAddress = null);

    Task LogUpdateAsync(int appId, string tableName, int recordId, string changedBy,
        IDictionary<string, (string? OldValue, string? NewValue)> changedFields,
        string? ipAddress = null);

    Task LogDeleteAsync(int appId, string tableName, int recordId, string changedBy,
        IDictionary<string, string?> snapshotValues,
        string? ipAddress = null);

    Task LogSchemaChangeAsync(int appId, string tableName, string changeDescription, string changedBy);

    Task<List<AuditLog>> GetRecordHistoryAsync(int appId, int recordId);

    Task<(List<AuditLog> Rows, int TotalCount)> SearchAuditAsync(
        int? appId, string? changedBy, DateTime? from, DateTime? to,
        string? action, int page, int pageSize);
}
