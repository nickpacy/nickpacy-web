using SpreadsheetToApp.Api.Models;

namespace SpreadsheetToApp.Api.Services;

public interface IRegistryService
{
    Task<PlatformApp?> GetAppAsync(string slug);
    Task<PlatformApp?> GetAppByIdAsync(int id);
    Task<List<PlatformColumn>> GetColumnsAsync(int appId);
    Task<List<AppListItem>> GetAppsForUserAsync(string username);
    Task<List<AppListItem>> GetAllAppsAsync();
    Task<int> CreateAppAsync(PlatformApp app);
    Task<List<int>> CreateColumnsAsync(int appId, IEnumerable<InferredColumn> columns);
    Task UpdateRowCountAsync(int appId, int count);
    Task SoftDeleteAppAsync(int appId, string deletedBy);
}
