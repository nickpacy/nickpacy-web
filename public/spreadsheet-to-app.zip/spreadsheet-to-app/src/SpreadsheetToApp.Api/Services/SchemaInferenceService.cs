using ClosedXML.Excel;
using SpreadsheetToApp.Api.Helpers;
using SpreadsheetToApp.Api.Models;
using System.Text.RegularExpressions;

namespace SpreadsheetToApp.Api.Services;

public partial class SchemaInferenceService : ISchemaInferenceService
{
    // Phone number patterns (US-centric, expandable)
    [GeneratedRegex(@"^(\+?1[\s\-.]?)?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}$")]
    private static partial Regex PhoneRegex();

    // SSN pattern
    [GeneratedRegex(@"^\d{3}-\d{2}-\d{4}$")]
    private static partial Regex SsnRegex();

    // Currency symbols
    [GeneratedRegex(@"^[$£€¥₹][\d,]+(\.\d{1,2})?$")]
    private static partial Regex CurrencyRegex();

    public List<string> GetSheetNames(string filePath)
    {
        using var wb = new XLWorkbook(filePath);
        return wb.Worksheets.Select(ws => ws.Name).ToList();
    }

    public InferredSchema InferSchema(string filePath, string sheetName)
    {
        using var wb = new XLWorkbook(filePath);
        var ws = wb.Worksheet(sheetName);
        var usedRange = ws.RangeUsed();

        if (usedRange == null)
            return new InferredSchema { TotalRows = 0, Columns = [] };

        var firstRow = usedRange.FirstRow();
        var totalRows = usedRange.RowCount() - 1; // exclude header

        var columns = new List<InferredColumn>();
        var columnIndex = 0;

        foreach (var headerCell in firstRow.Cells())
        {
            var rawHeader = headerCell.GetString().Trim();
            var columnName = ColumnNameSanitizer.Sanitize(rawHeader);
            var displayName = string.IsNullOrWhiteSpace(rawHeader) ? $"Column{columnIndex + 1}" : rawHeader;

            // Collect all non-empty values for this column
            var values = new List<string>();
            for (var rowNum = 2; rowNum <= usedRange.RowCount(); rowNum++)
            {
                var cell = ws.Cell(usedRange.FirstRow().RowNumber() + rowNum - 1,
                                   headerCell.Address.ColumnNumber);
                var val = cell.GetString().Trim();
                if (!string.IsNullOrWhiteSpace(val))
                    values.Add(val);
            }

            var inferred = InferColumn(rawHeader, columnName, displayName, values, columnIndex);
            inferred.WasRenamed = ColumnNameSanitizer.WasRenamed(rawHeader, columnName);
            inferred.ColumnOrder = columnIndex;
            columns.Add(inferred);
            columnIndex++;
        }

        return new InferredSchema
        {
            TotalRows = totalRows,
            Columns = columns
        };
    }

    private static InferredColumn InferColumn(
        string rawHeader, string columnName, string displayName,
        List<string> values, int order)
    {
        var col = new InferredColumn
        {
            RawHeader = rawHeader,
            ColumnName = columnName,
            DisplayName = displayName,
            ColumnOrder = order,
            IsSearchable = true
        };

        // Empty column
        if (values.Count == 0)
        {
            col.DataType = "NVARCHAR";
            col.MaxLength = 255;
            col.Confidence = 10;
            col.Warnings.Add("Column appears to be empty — possibly junk or placeholder.");
            return col;
        }

        // Blank header
        if (string.IsNullOrWhiteSpace(rawHeader))
        {
            col.DataType = "NVARCHAR";
            col.MaxLength = 255;
            col.Confidence = 0;
            col.Warnings.Add("Column has no header name — you must provide one before importing.");
            return col;
        }

        // ---- Try to infer type ----

        // BIT — true/false, yes/no, 1/0
        if (TryInferBit(values, out var bitConf))
        {
            col.DataType = "BIT";
            col.Confidence = bitConf;
            col.IsSearchable = false;
            return col;
        }

        // DATE / DATETIME
        if (TryInferDate(values, out var dateType, out var dateConf))
        {
            col.DataType = dateType;
            col.Confidence = dateConf;
            col.IsSearchable = false;
            return col;
        }

        // Numeric — check for leading zeros first (trap)
        var hasLeadingZero = values.Any(v => v.Length > 1 && v.StartsWith("0") && !v.StartsWith("0."));
        if (hasLeadingZero && values.All(v => v.All(c => char.IsDigit(c) || c == '-')))
        {
            col.DataType = "NVARCHAR";
            col.MaxLength = SizeNvarchar(values);
            col.Confidence = 60;
            col.Warnings.Add("Numeric column contains values starting with 0 — likely a code (zip, employee ID), stored as text.");
            return col;
        }

        // Check for phone numbers
        if (values.Count(v => PhoneRegex().IsMatch(v.Replace(" ", ""))) > values.Count * 0.7)
        {
            col.DataType = "NVARCHAR";
            col.MaxLength = 50;
            col.Confidence = 70;
            col.Warnings.Add("Values match phone number patterns — storing as text.");
            return col;
        }

        // Check for SSNs
        if (values.Any(v => SsnRegex().IsMatch(v)))
        {
            col.DataType = "NVARCHAR";
            col.MaxLength = 20;
            col.Confidence = 70;
            col.Warnings.Add("Values match SSN pattern — storing as text. Ensure data sensitivity is appropriate.");
            return col;
        }

        // Check for currency
        if (values.Any(v => CurrencyRegex().IsMatch(v.Replace(",", ""))))
        {
            col.DataType = "NVARCHAR";
            col.MaxLength = 50;
            col.Confidence = 60;
            col.Warnings.Add("Currency symbols detected — choose DECIMAL (strip symbols on import) or NVARCHAR (keep as-is).");
            return col;
        }

        // INT
        if (TryInferInt(values, out var intConf, out var hasNulls))
        {
            col.DataType = "INT";
            col.Confidence = intConf;
            if (hasNulls) col.Warnings.Add("Some rows are blank — NULLs will be stored for those rows.");
            col.IsSearchable = false;
            return col;
        }

        // DECIMAL
        if (TryInferDecimal(values, out var decConf, out hasNulls))
        {
            col.DataType = "DECIMAL";
            col.Confidence = decConf;
            if (hasNulls) col.Warnings.Add("Some rows are blank — NULLs will be stored for those rows.");
            col.IsSearchable = false;
            return col;
        }

        // Mixed content — some numeric, some text
        var numericCount = values.Count(v => decimal.TryParse(v, out _));
        if (numericCount > 0 && numericCount < values.Count)
        {
            col.DataType = "NVARCHAR";
            col.MaxLength = SizeNvarchar(values);
            col.Confidence = 40;
            col.Warnings.Add($"Mixed content: {numericCount} numeric values and {values.Count - numericCount} text values. Stored as text — review if this is correct.");
            return col;
        }

        // Default: NVARCHAR
        col.DataType = "NVARCHAR";
        col.MaxLength = SizeNvarchar(values);
        col.Confidence = 70;
        return col;
    }

    private static bool TryInferBit(List<string> values, out int confidence)
    {
        var bitValues = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "true", "false", "yes", "no", "1", "0", "y", "n" };
        var matches = values.Count(v => bitValues.Contains(v));
        if (matches == values.Count)
        {
            confidence = 85;
            return true;
        }
        confidence = 0;
        return false;
    }

    private static bool TryInferDate(List<string> values, out string dateType, out int confidence)
    {
        var dateCount = 0;
        var hasTime = false;
        foreach (var v in values)
        {
            if (DateTime.TryParse(v, out var dt))
            {
                dateCount++;
                if (dt.TimeOfDay != TimeSpan.Zero) hasTime = true;
            }
        }
        if (dateCount == values.Count)
        {
            dateType = hasTime ? "DATETIME" : "DATE";
            confidence = 95;
            return true;
        }
        dateType = "NVARCHAR";
        confidence = 0;
        return false;
    }

    private static bool TryInferInt(List<string> values, out int confidence, out bool hasNulls)
    {
        hasNulls = false;
        // Use the full row count including blanks to detect sparse columns
        var intCount = values.Count(v => long.TryParse(v, out _) && !v.Contains('.'));
        if (intCount == values.Count)
        {
            confidence = 90;
            return true;
        }
        // 85%+ numeric, remainder blank
        var allNonBlankAreInt = values.Where(v => !string.IsNullOrWhiteSpace(v))
                                      .All(v => long.TryParse(v, out _));
        if (allNonBlankAreInt && values.Count > 0)
        {
            hasNulls = true;
            confidence = 80;
            return true;
        }
        confidence = 0;
        return false;
    }

    private static bool TryInferDecimal(List<string> values, out int confidence, out bool hasNulls)
    {
        hasNulls = false;
        var decCount = values.Count(v => decimal.TryParse(v, out _));
        if (decCount == values.Count)
        {
            confidence = 90;
            return true;
        }
        var allNonBlankAreDec = values.Where(v => !string.IsNullOrWhiteSpace(v))
                                      .All(v => decimal.TryParse(v, out _));
        if (allNonBlankAreDec && values.Count > 0)
        {
            hasNulls = true;
            confidence = 80;
            return true;
        }
        confidence = 0;
        return false;
    }

    /// <summary>
    /// NVARCHAR length sizing (spec §5.2):
    /// max observed length × 1.5, rounded up to nearest bracket: 50, 100, 255, 500, MAX (-1).
    /// </summary>
    private static int SizeNvarchar(List<string> values)
    {
        if (values.Count == 0) return 255;
        var maxLen = values.Max(v => v.Length);
        var target = (int)Math.Ceiling(maxLen * 1.5);
        return target switch
        {
            <= 50 => 50,
            <= 100 => 100,
            <= 255 => 255,
            <= 500 => 500,
            _ => -1   // NVARCHAR(MAX)
        };
    }
}
