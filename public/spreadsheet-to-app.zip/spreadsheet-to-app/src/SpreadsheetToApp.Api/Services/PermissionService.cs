using Dapper;
using SpreadsheetToApp.Api.Models;
using System.Data;

namespace SpreadsheetToApp.Api.Services;

public class PermissionService(IDbConnection db) : IPermissionService
{
    public async Task EnsureUserRegisteredAsync(string username, string? displayName)
    {
        await db.ExecuteAsync(@"
            IF NOT EXISTS (SELECT 1 FROM platform_users WHERE username = @username)
                INSERT INTO platform_users (username, display_name, last_login)
                VALUES (@username, @displayName, GETDATE())
            ELSE
                UPDATE platform_users SET last_login = GETDATE(), display_name = COALESCE(@displayName, display_name)
                WHERE username = @username",
            new { username, displayName });
    }

    public async Task<string?> GetPermissionAsync(string username, string appSlug)
    {
        var result = await db.QueryFirstOrDefaultAsync<(bool IsAdmin, string? Permission)>(@"
            SELECT
                u.is_admin,
                p.permission
            FROM platform_users u
            LEFT JOIN platform_apps a ON a.slug = @appSlug AND a.is_active = 1 AND a.deleted_at IS NULL
            LEFT JOIN platform_app_permissions p ON p.app_id = a.id AND p.user_id = u.id
            WHERE u.username = @username AND u.is_active = 1",
            new { username, appSlug });

        if (result.IsAdmin) return PermissionLevel.Admin;
        return result.Permission;
    }

    public async Task<PlatformUser?> GetUserAsync(string username)
    {
        return await db.QueryFirstOrDefaultAsync<PlatformUser>(
            "SELECT * FROM platform_users WHERE username = @username",
            new { username });
    }

    public async Task GrantPermissionAsync(int appId, int userId, string permission, string grantedByUsername)
    {
        var grantor = await db.QueryFirstOrDefaultAsync<int?>(
            "SELECT id FROM platform_users WHERE username = @grantedByUsername",
            new { grantedByUsername });

        if (grantor == null) throw new InvalidOperationException("Grantor user not found.");

        await db.ExecuteAsync(@"
            IF EXISTS (SELECT 1 FROM platform_app_permissions WHERE app_id = @appId AND user_id = @userId)
                UPDATE platform_app_permissions SET permission = @permission, granted_by = @grantedBy, granted_at = GETDATE()
                WHERE app_id = @appId AND user_id = @userId
            ELSE
                INSERT INTO platform_app_permissions (app_id, user_id, permission, granted_by)
                VALUES (@appId, @userId, @permission, @grantedBy)",
            new { appId, userId, permission, grantedBy = grantor });
    }

    public async Task RevokePermissionAsync(int appId, int userId)
    {
        await db.ExecuteAsync(
            "DELETE FROM platform_app_permissions WHERE app_id = @appId AND user_id = @userId",
            new { appId, userId });
    }

    public async Task<List<PlatformAppPermission>> GetAppPermissionsAsync(int appId)
    {
        var rows = await db.QueryAsync<PlatformAppPermission>(@"
            SELECT p.*, u.username, u.display_name AS user_display_name
            FROM platform_app_permissions p
            JOIN platform_users u ON u.id = p.user_id
            WHERE p.app_id = @appId",
            new { appId });
        return rows.ToList();
    }
}
