using Dapper;
using SpreadsheetToApp.Api.Models;
using System.Data;

namespace SpreadsheetToApp.Api.Services;

public class AuditService(IDbConnection db) : IAuditService
{
    public async Task LogInsertAsync(int appId, string tableName, int recordId, string changedBy, string? ipAddress = null)
    {
        await db.ExecuteAsync(@"
            INSERT INTO platform_audit_log (app_id, table_name, record_id, action, changed_by, ip_address)
            VALUES (@appId, @tableName, @recordId, 'INSERT', @changedBy, @ipAddress)",
            new { appId, tableName, recordId, changedBy, ipAddress });
    }

    public async Task LogUpdateAsync(int appId, string tableName, int recordId, string changedBy,
        IDictionary<string, (string? OldValue, string? NewValue)> changedFields,
        string? ipAddress = null)
    {
        var logId = await db.QuerySingleAsync<long>(@"
            INSERT INTO platform_audit_log (app_id, table_name, record_id, action, changed_by, ip_address)
            VALUES (@appId, @tableName, @recordId, 'UPDATE', @changedBy, @ipAddress);
            SELECT SCOPE_IDENTITY();",
            new { appId, tableName, recordId, changedBy, ipAddress });

        foreach (var (columnName, (oldValue, newValue)) in changedFields)
        {
            await db.ExecuteAsync(@"
                INSERT INTO platform_audit_changes (audit_log_id, column_name, old_value, new_value)
                VALUES (@logId, @columnName, @oldValue, @newValue)",
                new { logId, columnName, oldValue, newValue });
        }
    }

    public async Task LogDeleteAsync(int appId, string tableName, int recordId, string changedBy,
        IDictionary<string, string?> snapshotValues,
        string? ipAddress = null)
    {
        var logId = await db.QuerySingleAsync<long>(@"
            INSERT INTO platform_audit_log (app_id, table_name, record_id, action, changed_by, ip_address)
            VALUES (@appId, @tableName, @recordId, 'DELETE', @changedBy, @ipAddress);
            SELECT SCOPE_IDENTITY();",
            new { appId, tableName, recordId, changedBy, ipAddress });

        foreach (var (columnName, oldValue) in snapshotValues)
        {
            await db.ExecuteAsync(@"
                INSERT INTO platform_audit_changes (audit_log_id, column_name, old_value, new_value)
                VALUES (@logId, @columnName, @oldValue, NULL)",
                new { logId, columnName, oldValue });
        }
    }

    public async Task LogSchemaChangeAsync(int appId, string tableName, string changeDescription, string changedBy)
    {
        var logId = await db.QuerySingleAsync<long>(@"
            INSERT INTO platform_audit_log (app_id, table_name, record_id, action, changed_by)
            VALUES (@appId, @tableName, -1, 'SCHEMA', @changedBy);
            SELECT SCOPE_IDENTITY();",
            new { appId, tableName, changedBy });

        await db.ExecuteAsync(@"
            INSERT INTO platform_audit_changes (audit_log_id, column_name, old_value, new_value)
            VALUES (@logId, '__schema', NULL, @changeDescription)",
            new { logId, changeDescription });
    }

    public async Task<List<AuditLog>> GetRecordHistoryAsync(int appId, int recordId)
    {
        var logs = (await db.QueryAsync<AuditLog>(@"
            SELECT * FROM platform_audit_log
            WHERE app_id = @appId AND record_id = @recordId
            ORDER BY changed_at DESC",
            new { appId, recordId })).ToList();

        foreach (var log in logs)
        {
            var changes = await db.QueryAsync<AuditChange>(
                "SELECT * FROM platform_audit_changes WHERE audit_log_id = @logId",
                new { logId = log.Id });
            log.Changes = changes.ToList();
        }

        return logs;
    }

    public async Task<(List<AuditLog> Rows, int TotalCount)> SearchAuditAsync(
        int? appId, string? changedBy, DateTime? from, DateTime? to,
        string? action, int page, int pageSize)
    {
        var sql = @"
            SELECT l.*, COUNT(*) OVER() AS total_count
            FROM platform_audit_log l
            WHERE 1=1";

        var p = new DynamicParameters();
        if (appId.HasValue)    { sql += " AND l.app_id = @appId";         p.Add("appId", appId); }
        if (!string.IsNullOrEmpty(changedBy)) { sql += " AND l.changed_by LIKE @changedBy"; p.Add("changedBy", $"%{changedBy}%"); }
        if (from.HasValue)     { sql += " AND l.changed_at >= @from";     p.Add("from", from); }
        if (to.HasValue)       { sql += " AND l.changed_at <= @to";       p.Add("to", to); }
        if (!string.IsNullOrEmpty(action)) { sql += " AND l.action = @action"; p.Add("action", action); }

        sql += " ORDER BY l.changed_at DESC OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY";
        p.Add("offset", (page - 1) * pageSize);
        p.Add("pageSize", pageSize);

        var rows = (await db.QueryAsync<AuditLog>(sql, p)).ToList();
        var total = rows.Count > 0
            ? await db.QuerySingleAsync<int>("SELECT COUNT(*) FROM platform_audit_log WHERE 1=1")
            : 0;

        return (rows, total);
    }
}
