using SpreadsheetToApp.Api.Models;

namespace SpreadsheetToApp.Api.Services;

public interface ISchemaInferenceService
{
    /// <summary>
    /// Reads the Excel file at the given path and infers column types.
    /// Returns a confidence-annotated schema for user review.
    /// </summary>
    InferredSchema InferSchema(string filePath, string sheetName);

    /// <summary>
    /// Returns sheet names from an Excel file.
    /// </summary>
    List<string> GetSheetNames(string filePath);
}
