namespace SpreadsheetToApp.Api.Models;

// -------------------------------------------------------
// Returned by POST /api/apps/upload
// -------------------------------------------------------
public class InferredSchema
{
    public string TempFileId { get; set; } = string.Empty;
    public string OriginalFileName { get; set; } = string.Empty;
    public List<string> SheetNames { get; set; } = [];
    public string SelectedSheet { get; set; } = string.Empty;
    public int TotalRows { get; set; }
    public List<InferredColumn> Columns { get; set; } = [];
}

public class InferredColumn
{
    public string RawHeader { get; set; } = string.Empty;
    public string ColumnName { get; set; } = string.Empty;     // sanitized SQL name
    public string DisplayName { get; set; } = string.Empty;    // original header
    public string DataType { get; set; } = "NVARCHAR";
    public int? MaxLength { get; set; }
    public int Confidence { get; set; }                        // 0-100
    public List<string> Warnings { get; set; } = [];
    public bool WasRenamed { get; set; }                       // sanitization changed the name
    public bool IsRequired { get; set; }
    public bool IsSearchable { get; set; } = true;
    public int ColumnOrder { get; set; }
    public bool Exclude { get; set; }                          // user can exclude a column from import
}

// -------------------------------------------------------
// Sent by Angular in POST /api/apps/confirm
// -------------------------------------------------------
public class ConfirmImportRequest
{
    public string TempFileId { get; set; } = string.Empty;
    public string SelectedSheet { get; set; } = string.Empty;
    public string AppSlug { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string ImportStrategy { get; set; } = "replace";    // replace | append | upsert
    public string? UpsertKeyCol { get; set; }
    public List<InferredColumn> Columns { get; set; } = [];    // user-reviewed and edited
}

// -------------------------------------------------------
// Returned by GET /api/meta/:slug
// -------------------------------------------------------
public class AppMetadata
{
    public int AppId { get; set; }
    public string Slug { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string Permission { get; set; } = string.Empty;   // admin | owner | readwrite | readonly
    public List<PlatformColumn> Columns { get; set; } = [];
    public int RowCount { get; set; }
    public string ImportStrategy { get; set; } = "replace";
    public string? UpsertKeyCol { get; set; }
}

// -------------------------------------------------------
// GET /api/apps list item
// -------------------------------------------------------
public class AppListItem
{
    public int Id { get; set; }
    public string Slug { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string Permission { get; set; } = string.Empty;
    public int RowCount { get; set; }
    public DateTime CreatedAt { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
}

// -------------------------------------------------------
// Schema edit request (PUT /api/apps/:slug/schema)
// -------------------------------------------------------
public class SchemaEditRequest
{
    public List<SchemaColumnChange> Changes { get; set; } = [];
}

public class SchemaColumnChange
{
    public int ColumnId { get; set; }
    public string? NewDisplayName { get; set; }
    public string? NewDataType { get; set; }
    public int? NewMaxLength { get; set; }
    public bool? NewIsRequired { get; set; }
    public bool? NewIsSearchable { get; set; }
    public int? NewColumnOrder { get; set; }
    public bool Delete { get; set; }
}

public class NewColumnRequest
{
    public string DisplayName { get; set; } = string.Empty;
    public string DataType { get; set; } = "NVARCHAR";
    public int? MaxLength { get; set; }
    public bool IsRequired { get; set; }
    public bool IsSearchable { get; set; } = true;
}

// -------------------------------------------------------
// Paginated data response
// -------------------------------------------------------
public class PagedResult
{
    public int TotalCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
    public IEnumerable<dynamic> Rows { get; set; } = [];
}
