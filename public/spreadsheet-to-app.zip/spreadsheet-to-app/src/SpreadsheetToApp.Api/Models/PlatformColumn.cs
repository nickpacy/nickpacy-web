namespace SpreadsheetToApp.Api.Models;

public class PlatformColumn
{
    public int Id { get; set; }
    public int AppId { get; set; }
    public string ColumnName { get; set; } = string.Empty;    // sanitized SQL column name
    public string DisplayName { get; set; } = string.Empty;   // label shown in UI
    public string DataType { get; set; } = "NVARCHAR";        // NVARCHAR | INT | DECIMAL | DATE | DATETIME | BIT
    public int? MaxLength { get; set; }                        // for NVARCHAR: 50, 100, 255, 500 or -1 for MAX
    public bool IsRequired { get; set; }
    public bool IsSearchable { get; set; } = true;
    public bool IsActive { get; set; } = true;
    public int ColumnOrder { get; set; }
    public DateTime? DeletedAt { get; set; }
}
