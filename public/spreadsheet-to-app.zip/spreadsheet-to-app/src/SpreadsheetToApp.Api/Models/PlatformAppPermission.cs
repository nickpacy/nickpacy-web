namespace SpreadsheetToApp.Api.Models;

public class PlatformAppPermission
{
    public int Id { get; set; }
    public int AppId { get; set; }
    public int UserId { get; set; }
    public string Permission { get; set; } = string.Empty;  // owner | readwrite | readonly
    public int GrantedBy { get; set; }
    public DateTime GrantedAt { get; set; }

    // Populated via JOIN when returned to callers
    public string? Username { get; set; }
    public string? UserDisplayName { get; set; }
}

public static class PermissionLevel
{
    public const string Owner = "owner";
    public const string ReadWrite = "readwrite";
    public const string ReadOnly = "readonly";
    public const string Admin = "admin";   // synthetic — derived from platform_users.is_admin
}
