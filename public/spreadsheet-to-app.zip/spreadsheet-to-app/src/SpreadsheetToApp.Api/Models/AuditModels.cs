namespace SpreadsheetToApp.Api.Models;

public class AuditLog
{
    public long Id { get; set; }
    public int AppId { get; set; }
    public string TableName { get; set; } = string.Empty;
    public int RecordId { get; set; }     // -1 for schema changes
    public string Action { get; set; } = string.Empty;  // INSERT | UPDATE | DELETE | SCHEMA
    public string ChangedBy { get; set; } = string.Empty;
    public DateTime ChangedAt { get; set; }
    public string? IpAddress { get; set; }
    public string? SessionId { get; set; }

    public List<AuditChange> Changes { get; set; } = [];
}

public class AuditChange
{
    public long Id { get; set; }
    public long AuditLogId { get; set; }
    public string ColumnName { get; set; } = string.Empty;
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
}
