namespace SpreadsheetToApp.Api.Models;

public class PlatformUser
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;   // DOMAIN\username
    public string? DisplayName { get; set; }
    public bool IsAdmin { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? LastLogin { get; set; }
    public bool IsActive { get; set; } = true;
}
