namespace SpreadsheetToApp.Api.Models;

public class PlatformApp
{
    public int Id { get; set; }
    public string Slug { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string TableName { get; set; } = string.Empty;
    public string ImportStrategy { get; set; } = "replace";   // replace | append | upsert
    public string? UpsertKeyCol { get; set; }
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public int RowCount { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? DeletedAt { get; set; }
}
