using SpreadsheetToApp.Api.Helpers;
using Xunit;

namespace SpreadsheetToApp.Tests;

public class ColumnSanitizerTests
{
    [Theory]
    [InlineData("Employee Name", "Employee_Name")]
    [InlineData("First Name", "First_Name")]
    [InlineData("Cost ($)", "Cost___")]
    [InlineData("123StartDigit", "col_123StartDigit")]
    [InlineData("", "col_unnamed")]
    [InlineData("   ", "col_unnamed")]
    public void Sanitize_RemovesIllegalCharacters(string input, string expected)
    {
        var result = ColumnNameSanitizer.Sanitize(input);
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("Name")]
    [InlineData("DATE")]
    [InlineData("ORDER")]
    [InlineData("User")]
    [InlineData("INDEX")]
    public void Sanitize_ReservedWords_GetColSuffix(string reservedWord)
    {
        var result = ColumnNameSanitizer.Sanitize(reservedWord);
        Assert.EndsWith("_col", result);
    }

    [Fact]
    public void Sanitize_LongName_TruncatedAt128()
    {
        var longName = new string('a', 200);
        var result = ColumnNameSanitizer.Sanitize(longName);
        Assert.Equal(128, result.Length);
    }

    [Fact]
    public void Sanitize_ValidName_Unchanged()
    {
        var result = ColumnNameSanitizer.Sanitize("employee_id");
        Assert.Equal("employee_id", result);
    }

    [Theory]
    [InlineData("Employee Name", "Employee_Name", true)]
    [InlineData("employee_id", "employee_id", false)]
    public void WasRenamed_DetectsRenaming(string raw, string sanitized, bool expectedRenamed)
    {
        Assert.Equal(expectedRenamed, ColumnNameSanitizer.WasRenamed(raw, sanitized));
    }
}
