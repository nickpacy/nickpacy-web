-- ============================================================
-- Spreadsheet to App Platform — AppGenDB Registry Tables
-- Run once on a fresh AppGenDB database
-- ============================================================

USE AppGenDB;
GO

-- --------------------------------------------------------
-- platform_apps
-- One row per uploaded spreadsheet / generated application.
-- --------------------------------------------------------
CREATE TABLE platform_apps (
    id               INT           IDENTITY PRIMARY KEY,
    slug             VARCHAR(100)  UNIQUE NOT NULL,         -- URL identifier: /app/:slug
    display_name     VARCHAR(255)  NOT NULL,                -- shown in sidebar nav
    table_name       VARCHAR(255)  NOT NULL,                -- actual SQL table e.g. app_employees_a3f9
    import_strategy  VARCHAR(20)   DEFAULT 'replace',       -- replace | append | upsert
    upsert_key_col   VARCHAR(255)  NULL,                    -- column used for upsert matching
    created_by       VARCHAR(100)  NOT NULL,
    created_at       DATETIME      DEFAULT GETDATE(),
    row_count        INT           DEFAULT 0,
    is_active        BIT           DEFAULT 1,
    deleted_at       DATETIME      NULL
);
GO

-- --------------------------------------------------------
-- platform_columns
-- One row per column in each app schema.
-- This is the metadata the entire dynamic system is built on.
-- --------------------------------------------------------
CREATE TABLE platform_columns (
    id            INT           IDENTITY PRIMARY KEY,
    app_id        INT           NOT NULL FOREIGN KEY REFERENCES platform_apps(id),
    column_name   VARCHAR(255)  NOT NULL,   -- actual SQL column name (sanitized)
    display_name  VARCHAR(255)  NOT NULL,   -- label shown in grid and form
    data_type     VARCHAR(50)   NOT NULL,   -- NVARCHAR | INT | DECIMAL | DATE | DATETIME | BIT
    max_length    INT           NULL,       -- for NVARCHAR: 50, 100, 255, 500 or -1 for MAX
    is_required   BIT           DEFAULT 0,
    is_searchable BIT           DEFAULT 1,
    is_active     BIT           DEFAULT 1,  -- soft delete flag
    column_order  INT           NOT NULL,
    deleted_at    DATETIME      NULL
);
GO

-- --------------------------------------------------------
-- platform_users
-- Platform user registry. Populated on first login via AD lookup.
-- --------------------------------------------------------
CREATE TABLE platform_users (
    id            INT           IDENTITY PRIMARY KEY,
    username      VARCHAR(100)  UNIQUE NOT NULL,    -- DOMAIN\username from AD
    display_name  VARCHAR(255)  NULL,
    is_admin      BIT           DEFAULT 0,          -- platform-wide admin flag
    created_at    DATETIME      DEFAULT GETDATE(),
    last_login    DATETIME      NULL,
    is_active     BIT           DEFAULT 1
);
GO

-- --------------------------------------------------------
-- platform_app_permissions
-- Per-app access control. A user with no row cannot see that app.
-- --------------------------------------------------------
CREATE TABLE platform_app_permissions (
    id          INT          IDENTITY PRIMARY KEY,
    app_id      INT          NOT NULL FOREIGN KEY REFERENCES platform_apps(id),
    user_id     INT          NOT NULL FOREIGN KEY REFERENCES platform_users(id),
    permission  VARCHAR(20)  NOT NULL,   -- owner | readwrite | readonly
    granted_by  INT          NOT NULL FOREIGN KEY REFERENCES platform_users(id),
    granted_at  DATETIME     DEFAULT GETDATE(),
    UNIQUE (app_id, user_id)
);
GO

-- --------------------------------------------------------
-- Indexes
-- --------------------------------------------------------
CREATE INDEX IX_platform_apps_slug      ON platform_apps(slug);
CREATE INDEX IX_platform_columns_app_id ON platform_columns(app_id);
CREATE INDEX IX_platform_perms_user     ON platform_app_permissions(user_id);
GO
