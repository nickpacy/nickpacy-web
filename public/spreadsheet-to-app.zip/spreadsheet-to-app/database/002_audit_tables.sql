-- ============================================================
-- Spreadsheet to App Platform — AppGenDB Audit Tables
-- Run after 001_registry_tables.sql
-- ============================================================

USE AppGenDB;
GO

-- --------------------------------------------------------
-- platform_audit_log
-- One row per data change event (INSERT, UPDATE, DELETE, SCHEMA).
-- --------------------------------------------------------
CREATE TABLE platform_audit_log (
    id          BIGINT        IDENTITY PRIMARY KEY,
    app_id      INT           NOT NULL,
    table_name  VARCHAR(255)  NOT NULL,
    record_id   INT           NOT NULL,         -- PK of the affected row (-1 for schema changes)
    action      VARCHAR(10)   NOT NULL,          -- INSERT | UPDATE | DELETE | SCHEMA
    changed_by  VARCHAR(100)  NOT NULL,          -- AD username (DOMAIN\user)
    changed_at  DATETIME      DEFAULT GETDATE(),
    ip_address  VARCHAR(45)   NULL,
    session_id  VARCHAR(100)  NULL
);
GO

-- --------------------------------------------------------
-- platform_audit_changes
-- Field-level change detail for UPDATE and DELETE events.
-- Only changed fields are recorded on UPDATE.
-- --------------------------------------------------------
CREATE TABLE platform_audit_changes (
    id           BIGINT         IDENTITY PRIMARY KEY,
    audit_log_id BIGINT         NOT NULL FOREIGN KEY REFERENCES platform_audit_log(id),
    column_name  VARCHAR(255)   NOT NULL,
    old_value    NVARCHAR(MAX)  NULL,
    new_value    NVARCHAR(MAX)  NULL
);
GO

-- --------------------------------------------------------
-- Indexes
-- --------------------------------------------------------
CREATE INDEX IX_audit_log_app_id     ON platform_audit_log(app_id);
CREATE INDEX IX_audit_log_changed_by ON platform_audit_log(changed_by);
CREATE INDEX IX_audit_log_changed_at ON platform_audit_log(changed_at);
CREATE INDEX IX_audit_changes_log_id ON platform_audit_changes(audit_log_id);
GO
