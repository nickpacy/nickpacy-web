import { HttpInterceptorFn } from '@angular/common/http';

/**
 * Attaches credentials to every API request.
 * Required for Windows Negotiate/NTLM authentication.
 * The browser sends the AD credentials automatically when withCredentials=true.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const apiReq = req.clone({ withCredentials: true });
  return next(apiReq);
};
