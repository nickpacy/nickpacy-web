import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { Router } from '@angular/router';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      switch (error.status) {
        case 401:
          // Windows Auth: browser handles the Negotiate challenge automatically.
          // A persistent 401 means the user isn't in AD or isn't permitted.
          console.error('Authentication failed — verify AD access.');
          break;
        case 403:
          router.navigate(['/unauthorized']);
          break;
        case 0:
          console.error('Network error — API unreachable.');
          break;
        default:
          console.error(`API error ${error.status}:`, error.message);
      }
      return throwError(() => error);
    })
  );
};
