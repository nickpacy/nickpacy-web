import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { map, catchError, of } from 'rxjs';

/**
 * Route guard that checks the user is authenticated before activating a route.
 * With Windows Auth, this just pings the API — if we get a response, we're authenticated.
 */
export const authGuard: CanActivateFn = () => {
  const auth   = inject(AuthService);
  const router = inject(Router);

  return auth.checkAuth().pipe(
    map(() => true),
    catchError(() => {
      router.navigate(['/unauthorized']);
      return of(false);
    })
  );
};
