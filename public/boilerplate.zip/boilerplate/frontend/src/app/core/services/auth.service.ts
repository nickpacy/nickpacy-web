import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, shareReplay } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface CurrentUser {
  username: string;
  displayName: string;
  roles: string[];
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiUrl;

  private currentUser$?: Observable<CurrentUser>;

  /** Returns the currently authenticated AD user. Cached per navigation. */
  checkAuth(): Observable<CurrentUser> {
    if (!this.currentUser$) {
      this.currentUser$ = this.http
        .get<CurrentUser>(`${this.baseUrl}/auth/me`)
        .pipe(shareReplay(1));
    }
    return this.currentUser$;
  }

  clearCache(): void {
    this.currentUser$ = undefined;
  }
}
