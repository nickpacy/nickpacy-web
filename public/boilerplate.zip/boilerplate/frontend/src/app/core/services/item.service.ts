import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface Item {
  id: number;
  name: string;
  description?: string;
  status: string;
  createdAt: string;
  createdBy: string;
}

export interface CreateItemRequest {
  name: string;
  description?: string;
}

export interface UpdateItemRequest {
  name: string;
  description?: string;
  status: string;
}

/**
 * Example service. Copy this pattern for each entity.
 * Swap "items" with your resource name.
 */
@Injectable({ providedIn: 'root' })
export class ItemService {
  private readonly http    = inject(HttpClient);
  private readonly baseUrl = `${environment.apiUrl}/items`;

  getAll(): Observable<Item[]> {
    return this.http.get<Item[]>(this.baseUrl);
  }

  getById(id: number): Observable<Item> {
    return this.http.get<Item>(`${this.baseUrl}/${id}`);
  }

  create(request: CreateItemRequest): Observable<Item> {
    return this.http.post<Item>(this.baseUrl, request);
  }

  update(id: number, request: UpdateItemRequest): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${id}`, request);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
