import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  template: `
    <div style="padding: 2rem;">
      <h1>Dashboard</h1>
      <p>Add your feature components here.</p>
    </div>
  `,
})
export class DashboardComponent {}
