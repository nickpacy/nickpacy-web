import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
  },
  {
    path: 'dashboard',
    loadComponent: () =>
      import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent),
    canActivate: [authGuard],
  },
  // Add feature routes here:
  // {
  //   path: 'items',
  //   loadComponent: () => import('./features/items/items.component').then(m => m.ItemsComponent),
  //   canActivate: [authGuard],
  // },
  {
    path: '**',
    redirectTo: 'dashboard',
  },
];
