export const environment = {
  production: false,
  apiUrl: '/api',  // Proxied by Angular dev server in development, Nginx in production
};
