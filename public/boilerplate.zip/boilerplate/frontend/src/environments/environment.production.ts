export const environment = {
  production: true,
  apiUrl: '/api',  // Nginx proxies /api/* to the API container in production
};
