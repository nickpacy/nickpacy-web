# Internal Tooling Boilerplate

ASP.NET Core 10 API + Angular 19 frontend, containerized with Podman.
Connects to an **external** SQL Server instance (Windows Auth or SQL Auth).

## Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| API       | ASP.NET Core 10, Dapper, C# 14    |
| Frontend  | Angular 19, standalone components |
| Container | Podman, Podman Compose            |
| Database  | External SQL Server (not in pod)  |
| CI/CD     | GitLab CI (`.gitlab-ci.yml`)      |

## Repo structure

```
/
├── api/                    # ASP.NET Core 10 Web API
│   ├── Controllers/
│   ├── Data/               # Dapper connection factory + repositories
│   ├── DTOs/
│   ├── Middleware/         # Error handling, AD auth
│   ├── Models/
│   ├── Services/
│   ├── api.csproj
│   ├── appsettings.json
│   ├── appsettings.Development.json
│   └── Program.cs
├── frontend/               # Angular 19 app
│   ├── src/
│   │   ├── app/
│   │   │   ├── core/       # HTTP interceptors, auth guard, services
│   │   │   ├── features/   # Feature modules (add yours here)
│   │   │   └── shared/     # Shared components, pipes, directives
│   │   ├── environments/
│   │   └── main.ts
│   ├── nginx.conf          # Nginx config for production container
│   ├── angular.json
│   └── package.json
├── podman/
│   ├── podman-compose.yml  # Full pod definition
│   ├── Containerfile.api   # API image (dotnet publish --self-contained)
│   └── Containerfile.frontend  # Nginx + Angular build
├── .gitlab-ci.yml          # CI pipeline: build → scan → push → deploy
└── README.md
```

## Quick start (local dev)

```bash
# 1. Start the API (connects to your local/dev SQL Server)
cd api
dotnet run

# 2. Start the Angular dev server (proxies /api to localhost:5000)
cd frontend
npm install
ng serve

# 3. Build and run as containers (requires Podman)
cd podman
podman-compose up --build
```

## Configuration

All environment-specific config is injected via environment variables.
Never commit secrets — use `.env` files locally, pipeline variables in CI.

### Required environment variables (API)

| Variable                    | Description                              |
|-----------------------------|------------------------------------------|
| `ConnectionStrings__Default`| Full SQL Server connection string        |
| `AllowedOrigins`            | CORS origins (e.g. `http://localhost:4200`) |
| `Jwt__Key`                  | JWT signing key (if using JWT auth)      |

### SQL Server auth modes

**SQL Auth (recommended for containers):**
```
Server=YOUR_SERVER;Database=YOUR_DB;User Id=YOUR_USER;Password=YOUR_PASS;TrustServerCertificate=True;
```

**Windows Auth (requires Kerberos keytab setup in container):**
```
Server=YOUR_SERVER;Database=YOUR_DB;Integrated Security=True;TrustServerCertificate=True;
```
See `podman/Containerfile.api` comments for Kerberos setup notes.

## Podman

```bash
# Build images
podman-compose -f podman/podman-compose.yml build

# Run the pod
podman-compose -f podman/podman-compose.yml up -d

# View logs
podman-compose -f podman/podman-compose.yml logs -f

# Stop
podman-compose -f podman/podman-compose.yml down
```

The frontend container (Nginx) listens on **port 4200**.
The API container listens on **port 5000** (internal, not exposed externally).
Nginx proxies `/api/*` to the API container.

## Adding a new feature

1. Add a model in `api/Models/`
2. Add a repository in `api/Data/`
3. Add a service in `api/Services/`
4. Add a controller in `api/Controllers/`
5. Add an Angular feature module in `frontend/src/app/features/`
