namespace Api.DTOs;

public record ItemDto(
    int Id,
    string Name,
    string? Description,
    string Status,
    DateTime CreatedAt,
    string CreatedBy);

public record CreateItemRequest(
    string Name,
    string? Description);

public record UpdateItemRequest(
    string Name,
    string? Description,
    string Status);
