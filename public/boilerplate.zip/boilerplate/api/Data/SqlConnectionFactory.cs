using System.Data;
using Microsoft.Data.SqlClient;

namespace Api.Data;

/// <summary>
/// Creates and opens SQL Server connections.
/// Inject this anywhere you need a Dapper connection.
/// </summary>
public interface IDbConnectionFactory
{
    Task<IDbConnection> CreateConnectionAsync(CancellationToken ct = default);
}

public class SqlConnectionFactory(string connectionString) : IDbConnectionFactory
{
    public async Task<IDbConnection> CreateConnectionAsync(CancellationToken ct = default)
    {
        var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(ct);
        return connection;
    }
}
