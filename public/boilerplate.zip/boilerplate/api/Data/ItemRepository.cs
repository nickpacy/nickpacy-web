using Api.Models;
using Dapper;

namespace Api.Data;

/// <summary>
/// Example repository. Copy this pattern for each entity.
/// Replace "Item" with your actual entity name.
/// </summary>
public interface IItemRepository
{
    Task<IEnumerable<Item>> GetAllAsync(CancellationToken ct = default);
    Task<Item?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<int> CreateAsync(Item item, CancellationToken ct = default);
    Task UpdateAsync(Item item, CancellationToken ct = default);
    Task DeleteAsync(int id, CancellationToken ct = default);
}

public class ItemRepository(IDbConnectionFactory dbFactory) : IItemRepository
{
    public async Task<IEnumerable<Item>> GetAllAsync(CancellationToken ct = default)
    {
        using var db = await dbFactory.CreateConnectionAsync(ct);
        return await db.QueryAsync<Item>(
            "SELECT Id, Name, Description, Status, CreatedAt, CreatedBy FROM Items ORDER BY CreatedAt DESC");
    }

    public async Task<Item?> GetByIdAsync(int id, CancellationToken ct = default)
    {
        using var db = await dbFactory.CreateConnectionAsync(ct);
        return await db.QuerySingleOrDefaultAsync<Item>(
            "SELECT Id, Name, Description, Status, CreatedAt, CreatedBy FROM Items WHERE Id = @Id",
            new { Id = id });
    }

    public async Task<int> CreateAsync(Item item, CancellationToken ct = default)
    {
        using var db = await dbFactory.CreateConnectionAsync(ct);
        return await db.ExecuteScalarAsync<int>(
            """
            INSERT INTO Items (Name, Description, Status, CreatedAt, CreatedBy)
            OUTPUT INSERTED.Id
            VALUES (@Name, @Description, @Status, GETUTCDATE(), @CreatedBy)
            """,
            item);
    }

    public async Task UpdateAsync(Item item, CancellationToken ct = default)
    {
        using var db = await dbFactory.CreateConnectionAsync(ct);
        await db.ExecuteAsync(
            """
            UPDATE Items
            SET Name        = @Name,
                Description = @Description,
                Status      = @Status
            WHERE Id = @Id
            """,
            item);
    }

    public async Task DeleteAsync(int id, CancellationToken ct = default)
    {
        using var db = await dbFactory.CreateConnectionAsync(ct);
        await db.ExecuteAsync("DELETE FROM Items WHERE Id = @Id", new { Id = id });
    }
}
