using System.Net;
using System.Text.Json;

namespace Api.Middleware;

public class ErrorHandlingMiddleware(RequestDelegate next, ILogger<ErrorHandlingMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unhandled exception for {Method} {Path}",
                context.Request.Method, context.Request.Path);

            context.Response.StatusCode  = (int)HttpStatusCode.InternalServerError;
            context.Response.ContentType = "application/json";

            var response = new
            {
                error   = "An unexpected error occurred.",
                // Only expose detail in development
                detail  = context.RequestServices
                    .GetRequiredService<IHostEnvironment>().IsDevelopment()
                    ? ex.Message
                    : null,
            };

            await context.Response.WriteAsync(JsonSerializer.Serialize(response));
        }
    }
}
