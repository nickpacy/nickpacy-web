using Api.Data;
using Api.Middleware;
using Api.Services;
using Microsoft.AspNetCore.Authentication.Negotiate;

var builder = WebApplication.CreateBuilder(args);

// ── Services ────────────────────────────────────────────────────────

builder.Services.AddControllers();
builder.Services.AddOpenApi();

// CORS — origins injected from environment / config
var allowedOrigins = builder.Configuration
    .GetSection("AllowedOrigins").Get<string[]>() ?? [];

builder.Services.AddCors(options =>
{
    options.AddPolicy("AppPolicy", policy =>
        policy.WithOrigins(allowedOrigins)
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials());
});

// Windows AD authentication (Negotiate = Kerberos / NTLM)
// Switch to JWT or cookie auth if running fully headless containers
builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
    .AddNegotiate();

builder.Services.AddAuthorization();

// SQL Server connection factory (Dapper)
builder.Services.AddSingleton<IDbConnectionFactory>(sp =>
    new SqlConnectionFactory(
        builder.Configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException(
                "ConnectionStrings:Default is required. " +
                "Set it via environment variable: ConnectionStrings__Default")));

// Register repositories and services here
// builder.Services.AddScoped<IDeliverableRepository, DeliverableRepository>();
// builder.Services.AddScoped<IDeliverableService, DeliverableService>();

// Health checks — verifies SQL Server reachability on startup
builder.Services.AddHealthChecks()
    .AddSqlServer(
        builder.Configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException("ConnectionStrings:Default is required."),
        name: "sql-server");

// ── App pipeline ────────────────────────────────────────────────────

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseMiddleware<ErrorHandlingMiddleware>();
app.UseCors("AppPolicy");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapHealthChecks("/health");

app.Run();
