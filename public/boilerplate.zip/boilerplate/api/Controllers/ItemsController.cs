using Api.Data;
using Api.DTOs;
using Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ItemsController(IItemRepository repository) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IEnumerable<ItemDto>>> GetAll(CancellationToken ct)
    {
        var items = await repository.GetAllAsync(ct);
        return Ok(items.Select(ToDto));
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ItemDto>> GetById(int id, CancellationToken ct)
    {
        var item = await repository.GetByIdAsync(id, ct);
        return item is null ? NotFound() : Ok(ToDto(item));
    }

    [HttpPost]
    public async Task<ActionResult<ItemDto>> Create(
        [FromBody] CreateItemRequest request, CancellationToken ct)
    {
        var item = new Item
        {
            Name        = request.Name,
            Description = request.Description,
            CreatedBy   = User.Identity?.Name ?? "unknown",
        };

        var id = await repository.CreateAsync(item, ct);
        item.Id = id;

        return CreatedAtAction(nameof(GetById), new { id }, ToDto(item));
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(
        int id, [FromBody] UpdateItemRequest request, CancellationToken ct)
    {
        var existing = await repository.GetByIdAsync(id, ct);
        if (existing is null) return NotFound();

        existing.Name        = request.Name;
        existing.Description = request.Description;
        existing.Status      = request.Status;

        await repository.UpdateAsync(existing, ct);
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        var existing = await repository.GetByIdAsync(id, ct);
        if (existing is null) return NotFound();

        await repository.DeleteAsync(id, ct);
        return NoContent();
    }

    private static ItemDto ToDto(Item i) =>
        new(i.Id, i.Name, i.Description, i.Status, i.CreatedAt, i.CreatedBy);
}
